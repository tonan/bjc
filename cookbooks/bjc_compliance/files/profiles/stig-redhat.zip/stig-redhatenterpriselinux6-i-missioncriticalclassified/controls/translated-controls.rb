control "SV-50237r1_rule" do
  title "Automated file system mounting tools must not be enabled unless needed."
  desc  "<VulnDiscussion>All filesystems that are required for the successful operation of the system should be explicitly listed in \"/etc/fstab\" by an administrator. New filesystems should not be arbitrarily introduced via the automounter.\n\nThe \"autofs\" daemon mounts and unmounts filesystems, such as user home directories shared via NFS, on demand. In addition, autofs can be used to handle removable media, and the default configuration provides the cdrom device as \"/misc/cd\". However, this method of providing access to removable media is not common, so autofs can almost always be disabled if NFS is not in use. Even if NFS is required, it is almost always possible to configure filesystem mounts statically by editing \"/etc/fstab\" rather than relying on the automounter. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe service("autofs").runlevels(/0/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/1/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/2/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/3/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/4/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/5/) do
    it { should be_disabled }
  end
  describe service("autofs").runlevels(/6/) do
    it { should be_disabled }
  end
end

control "SV-50238r3_rule" do
  title "Auditing must be enabled at boot by setting a kernel parameter."
  desc  "<VulnDiscussion>Each process on the system carries an \"auditable\" flag which indicates whether its activities can be audited. Although \"auditd\" takes care of enabling this for all processes which launch after it does, adding the kernel argument ensures it is set for every process during boot.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    its("content") { should match /^\s*kernel\s(?:\/boot)?\/vmlinuz.*audit=1.*$/ }
  end
end

control "SV-50243r1_rule" do
  title "The /etc/gshadow file must be owned by root."
  desc  "<VulnDiscussion>The \"/etc/gshadow\" file contains group password hashes. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/gshadow") do
    it { should exist }
  end
  describe file("/etc/gshadow") do
    its("uid") { should cmp 0 }
  end
end

control "SV-50248r1_rule" do
  title "The /etc/gshadow file must be group-owned by root."
  desc  "<VulnDiscussion>The \"/etc/gshadow\" file contains group password hashes. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/gshadow") do
    it { should exist }
  end
  describe file("/etc/gshadow") do
    its("gid") { should cmp 0 }
  end
end

control "SV-50249r1_rule" do
  title "The /etc/gshadow file must have mode 0000."
  desc  "<VulnDiscussion>The /etc/gshadow file contains group password hashes. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/gshadow") do
    it { should exist }
  end
  describe file("/etc/gshadow") do
    it { should_not be_executable.by "group" }
  end
  describe file("/etc/gshadow") do
    it { should_not be_readable.by "group" }
  end
  describe file("/etc/gshadow") do
    its("gid") { should cmp 0 }
  end
  describe file("/etc/gshadow") do
    it { should_not be_writable.by "group" }
  end
  describe file("/etc/gshadow") do
    it { should_not be_executable.by "other" }
  end
  describe file("/etc/gshadow") do
    it { should_not be_readable.by "other" }
  end
  describe file("/etc/gshadow") do
    it { should_not be_writable.by "other" }
  end
  describe file("/etc/gshadow") do
    its("sgid") { should equal false }
  end
  describe file("/etc/gshadow") do
    its("sticky") { should equal false }
  end
  describe file("/etc/gshadow") do
    its("suid") { should equal false }
  end
  describe file("/etc/gshadow") do
    it { should_not be_executable.by "owner" }
  end
  describe file("/etc/gshadow") do
    it { should_not be_readable.by "owner" }
  end
  describe file("/etc/gshadow") do
    its("uid") { should cmp 0 }
  end
  describe file("/etc/gshadow") do
    it { should_not be_writable.by "owner" }
  end
end

control "SV-50250r1_rule" do
  title "The /etc/passwd file must be owned by root."
  desc  "<VulnDiscussion>The \"/etc/passwd\" file contains information about the users that are configured on the system. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/passwd") do
    it { should exist }
  end
  describe file("/etc/passwd") do
    its("uid") { should cmp 0 }
  end
end

control "SV-50251r1_rule" do
  title "The /etc/passwd file must be group-owned by root."
  desc  "<VulnDiscussion>The \"/etc/passwd\" file contains information about the users that are configured on the system. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/passwd") do
    it { should exist }
  end
  describe file("/etc/passwd") do
    its("gid") { should cmp 0 }
  end
end

control "SV-50255r1_rule" do
  title "The system must use a separate file system for /tmp."
  desc  "<VulnDiscussion>The \"/tmp\" partition is used as temporary storage by many programs. Placing \"/tmp\" in its own partition enables the setting of more restrictive mount options, which can help protect programs which use it.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe mount("/tmp") do
    it { should be_mounted }
  end
end

control "SV-50256r1_rule" do
  title "The system must use a separate file system for /var."
  desc  "<VulnDiscussion>Ensuring that \"/var\" is mounted on its own partition enables the setting of more restrictive mount options. This helps protect system services such as daemons or other programs which use it. It is not uncommon for the \"/var\" directory to contain world-writable directories, installed by other software packages.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe mount("/var") do
    it { should be_mounted }
  end
end

control "SV-50257r1_rule" do
  title "The /etc/passwd file must have mode 0644 or less permissive."
  desc  "<VulnDiscussion>If the \"/etc/passwd\" file is writable by a group-owner or the world the risk of its compromise is increased. The file contains the list of accounts on the system and associated information, and protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/passwd") do
    it { should exist }
  end
  describe file("/etc/passwd") do
    it { should_not be_executable.by "group" }
  end
  describe file("/etc/passwd") do
    it { should be_readable.by "group" }
  end
  describe file("/etc/passwd") do
    its("gid") { should cmp 0 }
  end
  describe file("/etc/passwd") do
    it { should_not be_writable.by "group" }
  end
  describe file("/etc/passwd") do
    it { should_not be_executable.by "other" }
  end
  describe file("/etc/passwd") do
    it { should be_readable.by "other" }
  end
  describe file("/etc/passwd") do
    it { should_not be_writable.by "other" }
  end
  describe file("/etc/passwd") do
    its("sgid") { should equal false }
  end
  describe file("/etc/passwd") do
    its("sticky") { should equal false }
  end
  describe file("/etc/passwd") do
    its("suid") { should equal false }
  end
  describe file("/etc/passwd") do
    it { should_not be_executable.by "owner" }
  end
  describe file("/etc/passwd") do
    it { should be_readable.by "owner" }
  end
  describe file("/etc/passwd") do
    its("uid") { should cmp 0 }
  end
  describe file("/etc/passwd") do
    it { should be_writable.by "owner" }
  end
end

control "SV-50258r1_rule" do
  title "The /etc/group file must be owned by root."
  desc  "<VulnDiscussion>The \"/etc/group\" file contains information regarding groups that are configured on the system. Protection of this file is important for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/group") do
    it { should exist }
  end
  describe file("/etc/group") do
    its("uid") { should cmp 0 }
  end
end

control "SV-50259r1_rule" do
  title "The /etc/group file must be group-owned by root."
  desc  "<VulnDiscussion>The \"/etc/group\" file contains information regarding groups that are configured on the system. Protection of this file is important for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/group") do
    it { should exist }
  end
  describe file("/etc/group") do
    its("gid") { should cmp 0 }
  end
end

control "SV-50261r1_rule" do
  title "The /etc/group file must have mode 0644 or less permissive."
  desc  "<VulnDiscussion>The \"/etc/group\" file contains information regarding groups that are configured on the system. Protection of this file is important for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/group") do
    it { should exist }
  end
  describe file("/etc/group") do
    it { should_not be_executable.by "group" }
  end
  describe file("/etc/group") do
    it { should be_readable.by "group" }
  end
  describe file("/etc/group") do
    it { should_not be_writable.by "group" }
  end
  describe file("/etc/group") do
    it { should_not be_executable.by "other" }
  end
  describe file("/etc/group") do
    it { should be_readable.by "other" }
  end
  describe file("/etc/group") do
    it { should_not be_writable.by "other" }
  end
  describe file("/etc/group") do
    it { should_not be_executable.by "owner" }
  end
  describe file("/etc/group") do
    it { should be_readable.by "owner" }
  end
  describe file("/etc/group") do
    it { should be_writable.by "owner" }
  end
end

control "SV-50263r1_rule" do
  title "The system must use a separate file system for /var/log."
  desc  "<VulnDiscussion>Placing \"/var/log\" in its own partition enables better separation between log files and other files in \"/var/\".</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe mount("/var/log") do
    it { should be_mounted }
  end
end

control "SV-50267r1_rule" do
  title "The system must use a separate file system for the system audit data path."
  desc  "<VulnDiscussion>Placing \"/var/log/audit\" in its own partition enables better separation between audit files and other files, and helps ensure that auditing cannot be halted due to the partition running out of space.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe mount("/var/log/audit") do
    it { should be_mounted }
  end
end

control "SV-50270r2_rule" do
  title "The audit system must alert designated staff members when the audit storage volume approaches capacity."
  desc  "<VulnDiscussion>Notifying administrators of an impending disk space problem may allow them to take corrective action prior to any disruption.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/auditd.conf") do
    its("content") { should match /^[ ]*space_left_action[ ]+=[ ]+(\S+)[ ]*$/ }
  end
  file("/etc/audit/auditd.conf").content.to_s.scan(/^[ ]*space_left_action[ ]+=[ ]+(\S+)[ ]*$/).flatten.each do |entry|
    describe entry do
      it { should cmp "email" }
    end
  end
end

control "SV-50273r1_rule" do
  title "The system must use a separate file system for user home directories."
  desc  "<VulnDiscussion>Ensuring that \"/home\" is mounted on its own partition enables the setting of more restrictive mount options, and also helps ensure that users cannot trivially fill partitions used for log or audit data storage.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe mount("/home") do
    it { should be_mounted }
  end
end

control "SV-50275r2_rule" do
  title "The system must require passwords to contain a minimum of 15 characters."
  desc  "<VulnDiscussion>Requiring a minimum password length makes password cracking attacks more difficult by ensuring a larger search space. However, any security benefit from an onerous requirement must be carefully weighed against usability problems, support costs, or counterproductive behavior that may result.\n\nWhile it does not negate the password length requirement, it is preferable to migrate from a password-based authentication scheme to a stronger one based on PKI (public key infrastructure).</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^PASS_MIN_LEN\s+(\d+)\s*$/ }
  end
  file("/etc/login.defs").content.to_s.scan(/^PASS_MIN_LEN\s+(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 15 }
    end
  end
end

control "SV-50277r1_rule" do
  title "Users must not be able to change passwords more than once every 24 hours."
  desc  "<VulnDiscussion>Setting the minimum password age protects against users cycling back to a favorite password after satisfying the password reuse requirement.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^[\s]*PASS_MIN_DAYS[\s]+(\d+)\s*$/ }
  end
  file("/etc/login.defs").content.to_s.scan(/^[\s]*PASS_MIN_DAYS[\s]+(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 1 }
    end
  end
end

control "SV-50279r1_rule" do
  title "User passwords must be changed at least every 60 days."
  desc  "<VulnDiscussion>Setting the password maximum age ensures users are required to periodically change their passwords. This could possibly decrease the utility of a stolen password. Requiring shorter password lifetimes increases the risk of users writing down the password in a convenient location subject to physical compromise.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^[\s]*PASS_MAX_DAYS[\s]+(\d+)\s*$/ }
  end
  file("/etc/login.defs").content.to_s.scan(/^[\s]*PASS_MAX_DAYS[\s]+(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp <= 60 }
    end
  end
end

control "SV-50280r1_rule" do
  title "Users must be warned 7 days in advance of password expiration."
  desc  "<VulnDiscussion>Setting the password warning age enables users to make the change at a practical time.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^[\s]*PASS_WARN_AGE[\s]*(\d+)\s*$/ }
  end
  file("/etc/login.defs").content.to_s.scan(/^[\s]*PASS_WARN_AGE[\s]*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 7 }
    end
  end
end

control "SV-50282r1_rule" do
  title "The system must require passwords to contain at least one numeric character."
  desc  "<VulnDiscussion>Requiring digits makes password guessing attacks more difficult by ensuring a larger search space.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]dcredit=(-?\d+)(?:[\s]|$)/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]dcredit=(-?\d+)(?:[\s]|$)/).flatten.each do |entry|
    describe entry do
      it { should cmp <= -1 }
    end
  end
end

control "SV-50283r1_rule" do
  title "The system package management tool must cryptographically verify the authenticity of system software packages during installation."
  desc  "<VulnDiscussion>Ensuring the validity of packages' cryptographic signatures prior to installation ensures the provenance of the software and protects against malicious tampering.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/yum.conf") do
    its("content") { should match /^\s*gpgcheck\s*=\s*1\s*$/ }
  end
end

control "SV-50288r1_rule" do
  title "The system package management tool must cryptographically verify the authenticity of all software packages during installation."
  desc  "<VulnDiscussion>Ensuring all packages' cryptographic signatures are valid prior to installation ensures the provenance of the software and protects against malicious tampering.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/yum.repos.d -type f -regex .\\*/.\\*").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should_not match /^\s*gpgcheck\s*=\s*0\s*$/ }
    end
  end
end

control "SV-50290r1_rule" do
  title "A file integrity tool must be installed."
  desc  "<VulnDiscussion>The AIDE package must be installed if it is to be available for integrity checking.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("aide") do
    it { should be_installed }
  end
end

control "SV-50291r4_rule" do
  title "The operating system must enforce requirements for the connection of mobile devices to operating systems."
  desc  "<VulnDiscussion>USB storage devices such as thumb drives can be used to introduce unauthorized software and other vulnerabilities. Support for these devices should be disabled and the devices themselves should be tightly controlled.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*install\s+usb-storage\s+(\/bin\/true)\s*$/ }
    end
  end
  describe file("/etc/modprobe.conf") do
    its("content") { should match /^\s*install\s+usb-storage\s+(\/bin\/true)\s*$/ }
  end
end

control "SV-50292r1_rule" do
  title "There must be no .rhosts or hosts.equiv files on the system."
  desc  "<VulnDiscussion>Trust files are convenient, but when used in conjunction with the R-services, they can allow unauthenticated access to a system.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/root/^\\.(r|s)hosts$") do
    it { should_not exist }
  end
  describe command("find /home -regex .\\*/\\^\\\\.\\(r\\|s\\)hosts\\$ -type f  -maxdepth 1") do
    its("stdout") { should be_empty }
  end
  describe file("/etc/^s?hosts\\.equiv$") do
    it { should_not exist }
  end
end

control "SV-50293r1_rule" do
  title "The system must prevent the root account from logging in from virtual consoles."
  desc  "<VulnDiscussion>Preventing direct root login to virtual console devices helps ensure accountability for actions taken on the system using the root account. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/securetty") do
    its("content") { should_not match /^vc\/[0-9]+$/ }
  end
end

control "SV-50295r1_rule" do
  title "The system must prevent the root account from logging in from serial consoles."
  desc  "<VulnDiscussion>Preventing direct root login to serial port interfaces helps ensure accountability for actions taken on the systems using the root account.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/securetty") do
    its("content") { should_not match /^ttyS[0-9]+$/ }
  end
end

control "SV-50296r1_rule" do
  title "Audit log files must be owned by root."
  desc  "<VulnDiscussion>If non-privileged users can write to audit logs, audit trails can be modified or destroyed.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe command("find /var/log/audit -regex .\\*/\\^.\\*\\$ -user 0") do
    its("stdout") { should_not be_empty }
  end
  describe command("find /var/log/audit -type d -user 0") do
    its("stdout") { should_not be_empty }
  end
end

control "SV-50298r2_rule" do
  title "The system must not have accounts configured with blank or null passwords."
  desc  "<VulnDiscussion>If an account has an empty password, anyone could log in and run commands with the privileges of that account. Accounts with empty passwords should never be used in operational environments.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should_not match /\s*nullok\s*/ }
  end
end

control "SV-50299r1_rule" do
  title "Audit log files must have mode 0640 or less permissive."
  desc  "<VulnDiscussion>If users can write to audit logs, audit trails can be modified or destroyed.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe command("find /var/log/audit -regex .\\*/\\^.\\*\\$ -perm -07137 -xdev") do
    its("stdout") { should be_empty }
  end
end

control "SV-50300r1_rule" do
  title "The /etc/passwd file must not contain password hashes."
  desc  "<VulnDiscussion>The hashes for all user account passwords should be stored in the file \"/etc/shadow\" and never in \"/etc/passwd\", which is readable by all users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/passwd") do
    its("content") { should match /^[^:]*:([^:]*):/ }
  end
  file("/etc/passwd").content.to_s.scan(/^[^:]*:([^:]*):/).flatten.each do |entry|
    describe entry do
      it { should eq "x" }
    end
  end
end

control "SV-50301r2_rule" do
  title "The root account must be the only account having a UID of 0."
  desc  "<VulnDiscussion>An account has root authority if it has a UID of 0. Multiple accounts with a UID of 0 afford more opportunity for potential intruders to guess a password for a privileged account. Proper configuration of sudo is recommended to afford multiple system administrators access to root privileges in an accountable manner.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/passwd") do
    its("content") { should_not match /^(?!root:)[^:]*:[^:]:0/ }
  end
end

control "SV-50302r4_rule" do
  title "The system must disable accounts after excessive login failures within a 15-minute interval."
  desc  "<VulnDiscussion>Locking out user accounts after a number of incorrect attempts within a specific period of time prevents direct password guessing attacks.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 900 }
    end
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 900 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 900 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=(?:[0-9]+).*unlock_time=(?:[0-9]+).*fail_interval=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 900 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
end

control "SV-50303r1_rule" do
  title "The /etc/shadow file must be owned by root."
  desc  "<VulnDiscussion>The \"/etc/shadow\" file contains the list of local system accounts and stores password hashes. Protection of this file is critical for system security. Failure to give ownership of this file to root provides the designated owner with access to sensitive information which could weaken the system security posture.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/shadow") do
    it { should exist }
  end
  describe file("/etc/shadow") do
    its("uid") { should cmp 0 }
  end
end

control "SV-50304r1_rule" do
  title "The /etc/shadow file must be group-owned by root."
  desc  "<VulnDiscussion>The \"/etc/shadow\" file stores password hashes. Protection of this file is critical for system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/shadow") do
    it { should exist }
  end
  describe file("/etc/shadow") do
    its("gid") { should cmp 0 }
  end
end

control "SV-50305r1_rule" do
  title "The /etc/shadow file must have mode 0000."
  desc  "<VulnDiscussion>The \"/etc/shadow\" file contains the list of local system accounts and stores password hashes. Protection of this file is critical for system security. Failure to give ownership of this file to root provides the designated owner with access to sensitive information which could weaken the system security posture.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/shadow") do
    it { should exist }
  end
  describe file("/etc/shadow") do
    it { should_not be_executable.by "group" }
  end
  describe file("/etc/shadow") do
    it { should_not be_readable.by "group" }
  end
  describe file("/etc/shadow") do
    its("gid") { should cmp 0 }
  end
  describe file("/etc/shadow") do
    it { should_not be_writable.by "group" }
  end
  describe file("/etc/shadow") do
    it { should_not be_executable.by "other" }
  end
  describe file("/etc/shadow") do
    it { should_not be_readable.by "other" }
  end
  describe file("/etc/shadow") do
    it { should_not be_writable.by "other" }
  end
  describe file("/etc/shadow") do
    its("sgid") { should equal false }
  end
  describe file("/etc/shadow") do
    its("sticky") { should equal false }
  end
  describe file("/etc/shadow") do
    its("suid") { should equal false }
  end
  describe file("/etc/shadow") do
    it { should_not be_executable.by "owner" }
  end
  describe file("/etc/shadow") do
    it { should_not be_readable.by "owner" }
  end
  describe file("/etc/shadow") do
    its("uid") { should cmp 0 }
  end
  describe file("/etc/shadow") do
    it { should_not be_writable.by "owner" }
  end
end

control "SV-50312r2_rule" do
  title "IP forwarding for IPv4 must not be enabled, unless the system is a router."
  desc  "<VulnDiscussion>IP forwarding permits the kernel to forward packets from one network interface to another. The ability to forward packets between two networks is only appropriate for systems acting as routers.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.ip_forward") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.ip_forward") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.ip_forward[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50313r2_rule" do
  title "The operating system must prevent public IPv4 access into an organizations internal networks, except as appropriately mediated by managed interfaces employing boundary protection devices."
  desc  "<VulnDiscussion>The \"iptables\" service provides the system's host-based firewalling capability for IPv4 and ICMP.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50314r1_rule" do
  title "The systems local IPv4 firewall must implement a deny-all, allow-by-exception policy for inbound packets."
  desc  "<VulnDiscussion>In \"iptables\" the default policy is applied only after all the applicable rules in the table are examined for a match. Setting the default policy to \"DROP\" implements proper design for a firewall, i.e., any packets which are not explicitly permitted should not be accepted.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/sysconfig/iptables") do
    its("content") { should match /^[\s]*:INPUT\sDROP\s\[0:0\]/ }
  end
  describe file("/etc/sysconfig/iptables") do
    its("content") { should_not match /^[\s]*:INPUT\ACCEPT\s\[0:0\]/ }
  end
end

control "SV-50315r3_rule" do
  title "The Datagram Congestion Control Protocol (DCCP) must be disabled unless required."
  desc  "<VulnDiscussion>Disabling DCCP protects the system against exploitation of any flaws in its implementation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*install\s+dccp\s+(\/bin\/true)\s*$/ }
    end
  end
  describe file("/etc/modprobe.conf") do
    its("content") { should match /^\s*install\s+dccp\s+(\/bin\/true)\s*$/ }
  end
end

control "SV-50316r3_rule" do
  title "The Stream Control Transmission Protocol (SCTP) must be disabled unless required."
  desc  "<VulnDiscussion>Disabling SCTP protects the system against exploitation of any flaws in its implementation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*install\s+sctp\s+(\/bin\/true)\s*$/ }
    end
  end
  describe file("/etc/modprobe.conf") do
    its("content") { should match /^\s*install\s+sctp\s+(\/bin\/true)\s*$/ }
  end
end

control "SV-50317r3_rule" do
  title "The Reliable Datagram Sockets (RDS) protocol must be disabled unless required."
  desc  "<VulnDiscussion>Disabling RDS protects the system against exploitation of any flaws in its implementation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*install\s+rds\s+(\/bin\/true)\s*$/ }
    end
  end
  describe file("/etc/modprobe.conf") do
    its("content") { should match /^\s*install\s+rds\s+(\/bin\/true)\s*$/ }
  end
end

control "SV-50318r3_rule" do
  title "The Transparent Inter-Process Communication (TIPC) protocol must be disabled unless required."
  desc  "<VulnDiscussion>Disabling TIPC protects the system against exploitation of any flaws in its implementation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*install\s+tipc\s+(\/bin\/true)\s*$/ }
    end
  end
  describe file("/etc/modprobe.conf") do
    its("content") { should match /^\s*install\s+tipc\s+(\/bin\/true)\s*$/ }
  end
end

control "SV-50319r2_rule" do
  title "All rsyslog-generated log files must be owned by root."
  desc  "<VulnDiscussion>The log files generated by rsyslog contain valuable information regarding system configuration, user authentication, and other such information. Log files should be protected from unauthorized access.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource file_test could not be loaded: Don't understand SCAP::OVAL::Objects: file_object/set" do
    skip "SCAP oval resource file_test could not be loaded: Don't understand SCAP::OVAL::Objects: file_object/set"
  end
  describe file("/etc/rsyslog.conf") do
    its("content") { should match /^[^#\$\s]+\s+-?(\/.*)$/ }
  end
end

control "SV-50321r1_rule" do
  title "The operating system must back up audit records on an organization defined frequency onto a different system or media than the system being audited."
  desc  "<VulnDiscussion>A log server (loghost) receives syslog messages from one or more systems. This data can be used as an additional log source in the event a system is compromised and its local logs are suspect. Forwarding log messages to a remote loghost also provides system administrators with a centralized place to view the status of multiple hosts within the enterprise.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/rsyslog.conf") do
    its("content") { should match /^\*\.\*[\s]+(?:@|\:omrelp\:)/ }
  end
  command("find /etc/rsyslog.d -type f -regex .\\*/.\\*").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\*\.\*[\s]+(?:@|\:omrelp\:)/ }
    end
  end
end

control "SV-50322r1_rule" do
  title "The operating system must support the requirement to centrally manage the content of audit records generated by organization defined information system components."
  desc  "<VulnDiscussion>A log server (loghost) receives syslog messages from one or more systems. This data can be used as an additional log source in the event a system is compromised and its local logs are suspect. Forwarding log messages to a remote loghost also provides system administrators with a centralized place to view the status of multiple hosts within the enterprise.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/rsyslog.conf") do
    its("content") { should match /^\*\.\*[\s]+(?:@|\:omrelp\:)/ }
  end
  command("find /etc/rsyslog.d -type f -regex .\\*/.\\*").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\*\.\*[\s]+(?:@|\:omrelp\:)/ }
    end
  end
end

control "SV-50323r3_rule" do
  title "The audit system must be configured to audit all attempts to alter system time through settimeofday."
  desc  "<VulnDiscussion>Arbitrary changes to the system time can be used to obfuscate nefarious activities in log files, as well as to confuse network services that are highly dependent upon an accurate system time (such as sshd). All changes to the system time should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50324r2_rule" do
  title "The system must not accept IPv4 source-routed packets on any interface."
  desc  "<VulnDiscussion>Accepting source-routed packets in the IPv4 protocol has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.accept_source_route") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.accept_source_route") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.accept_source_route[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50325r2_rule" do
  title "The system must not accept ICMPv4 redirect packets on any interface."
  desc  "<VulnDiscussion>Accepting ICMP redirects has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.accept_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.accept_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.accept_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50326r4_rule" do
  title "The audit system must be configured to audit all attempts to alter system time through stime."
  desc  "<VulnDiscussion>Arbitrary changes to the system time can be used to obfuscate nefarious activities in log files, as well as to confuse network services that are highly dependent upon an accurate system time (such as sshd). All changes to the system time should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50327r2_rule" do
  title "The system must not accept ICMPv4 secure redirect packets on any interface."
  desc  "<VulnDiscussion>Accepting \"secure\" ICMP redirects (from those gateways listed as default gateways) has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.secure_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.secure_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.secure_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50328r3_rule" do
  title "The audit system must be configured to audit all attempts to alter system time through clock_settime."
  desc  "<VulnDiscussion>Arbitrary changes to the system time can be used to obfuscate nefarious activities in log files, as well as to confuse network services that are highly dependent upon an accurate system time (such as sshd). All changes to the system time should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50329r2_rule" do
  title "The system must log Martian packets."
  desc  "<VulnDiscussion>The presence of \"martian\" packets (which have impossible addresses) as well as spoofed packets, source-routed packets, and redirects could be a sign of nefarious network activity. Logging these packets enables this activity to be detected.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.log_martians") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.log_martians") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.log_martians[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50330r2_rule" do
  title "The system must not accept IPv4 source-routed packets by default."
  desc  "<VulnDiscussion>Accepting source-routed packets in the IPv4 protocol has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.default.accept_source_route") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.default.accept_source_route") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.default.accept_source_route[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50331r2_rule" do
  title "The audit system must be configured to audit all attempts to alter system time through /etc/localtime."
  desc  "<VulnDiscussion>Arbitrary changes to the system time can be used to obfuscate nefarious activities in log files, as well as to confuse network services that are highly dependent upon an accurate system time (such as sshd). All changes to the system time should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-w[\s]+\/etc\/localtime[\s]+-p[\s]+\b([rx]*w[rx]*a[rx]*|[rx]*a[rx]*w[rx]*)\b.*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50332r2_rule" do
  title "The operating system must automatically audit account creation."
  desc  "<VulnDiscussion>In addition to auditing new user and group accounts, these watches will alert the system administrator(s) to any modifications. Any unexpected users, groups, or modifications should be investigated for legitimacy.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/group\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/passwd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/gshadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/shadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/security\/opasswd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
end

control "SV-50333r2_rule" do
  title "The system must not accept ICMPv4 secure redirect packets by default."
  desc  "<VulnDiscussion>Accepting \"secure\" ICMP redirects (from those gateways listed as default gateways) has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.default.secure_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.default.secure_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.default.secure_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50334r3_rule" do
  title "The system must ignore ICMPv4 redirect messages by default."
  desc  "<VulnDiscussion>This feature of the IPv4 protocol has few legitimate uses. It should be disabled unless it is absolutely required.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.default.accept_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.default.accept_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.default.accept_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50335r2_rule" do
  title "The operating system must automatically audit account modification."
  desc  "<VulnDiscussion>In addition to auditing new user and group accounts, these watches will alert the system administrator(s) to any modifications. Any unexpected users, groups, or modifications should be investigated for legitimacy.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/group\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/passwd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/gshadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/shadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/security\/opasswd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
end

control "SV-50336r2_rule" do
  title "The system must not respond to ICMPv4 sent to a broadcast address."
  desc  "<VulnDiscussion>Ignoring ICMP echo requests (pings) sent to broadcast or multicast addresses makes the system slightly more difficult to enumerate on the network.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.icmp_echo_ignore_broadcasts") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.icmp_echo_ignore_broadcasts") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.icmp_echo_ignore_broadcasts[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50337r2_rule" do
  title "The operating system must automatically audit account disabling actions."
  desc  "<VulnDiscussion>In addition to auditing new user and group accounts, these watches will alert the system administrator(s) to any modifications. Any unexpected users, groups, or modifications should be investigated for legitimacy.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/group\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/passwd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/gshadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/shadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/security\/opasswd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
end

control "SV-50338r2_rule" do
  title "The system must ignore ICMPv4 bogus error responses."
  desc  "<VulnDiscussion>Ignoring bogus ICMP error responses reduces log size, although some activity would not be logged.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.icmp_ignore_bogus_error_responses") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.icmp_ignore_bogus_error_responses") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.icmp_ignore_bogus_error_responses[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50339r2_rule" do
  title "The operating system must automatically audit account termination."
  desc  "<VulnDiscussion>In addition to auditing new user and group accounts, these watches will alert the system administrator(s) to any modifications. Any unexpected users, groups, or modifications should be investigated for legitimacy.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/group\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/passwd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/gshadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/shadow\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/security\/opasswd\s+\-p\s+wa\s+\-k\s+\w+\s*$/ }
  end
end

control "SV-50340r2_rule" do
  title "The system must be configured to use TCP syncookies when experiencing a TCP SYN flood."
  desc  "<VulnDiscussion>A TCP SYN flood attack can cause a denial of service by filling a system's TCP connection table with connections in the SYN_RCVD state. Syncookies can be used to track a connection when a subsequent ACK is received, verifying the initiator is attempting a valid connection and is not a flood source. This feature is activated when a flood condition is detected, and enables the system to continue servicing valid connection requests.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.tcp_syncookies") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.tcp_syncookies") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.tcp_syncookies[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50342r2_rule" do
  title "The audit system must be configured to audit modifications to the systems Mandatory Access Control (MAC) configuration (SELinux)."
  desc  "<VulnDiscussion>The system's mandatory access policy (SELinux) should not be arbitrarily changed by anything other than administrator action. All changes to MAC policy should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/selinux\/\s+\-p\s+wa\s+\-k\s+[-\w]+\s*$/ }
  end
end

control "SV-50343r2_rule" do
  title "The system must use a reverse-path filter for IPv4 network traffic when possible on all interfaces."
  desc  "<VulnDiscussion>Enabling reverse path filtering drops packets with source addresses that should not have been able to be received on the interface they were received on. It should not be used on systems which are routers for complicated networks, but is helpful for end hosts and routers serving small networks.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.rp_filter") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.rp_filter") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.rp_filter[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50344r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using chmod."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+chmod[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50345r2_rule" do
  title "The system must use a reverse-path filter for IPv4 network traffic when possible by default."
  desc  "<VulnDiscussion>Enabling reverse path filtering drops packets with source addresses that should not have been able to be received on the interface they were received on. It should not be used on systems which are routers for complicated networks, but is helpful for end hosts and routers serving small networks.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.default.rp_filter") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.default.rp_filter") do
    its("value") { should eq 1 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.default.rp_filter[\s]*=[\s]*1[\s]*$/ }
  end
end

control "SV-50346r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using chown."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+chown[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50347r3_rule" do
  title "The IPv6 protocol handler must not be bound to the network stack unless needed."
  desc  "<VulnDiscussion>Any unnecessary network stacks - including IPv6 - should be disabled, to reduce the vulnerability to exploitation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/modprobe.d -type f -regex .\\*/\\^.\\*\\\\.conf\\$").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^\s*options\s+ipv6\s+.*disable=1.*$/ }
    end
  end
end

control "SV-50348r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fchmod."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fchmod[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50349r3_rule" do
  title "The system must ignore ICMPv6 redirects by default."
  desc  "<VulnDiscussion>An illicit ICMP redirect message could result in a man-in-the-middle attack.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50351r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fchmodat."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fchmodat[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50353r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fchown."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fchown[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50355r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fchownat."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fchownat[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50356r2_rule" do
  title "The system must employ a local IPv4 firewall."
  desc  "<VulnDiscussion>The \"iptables\" service provides the system's host-based firewalling capability for IPv4 and ICMP.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50357r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fremovexattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fremovexattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50358r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using fsetxattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+fsetxattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50359r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using lchown."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+lchown[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50360r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using lremovexattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+lremovexattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50362r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using lsetxattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+lsetxattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50364r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using removexattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^-[Aa][\s]*(?:exit,always|always,exit)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+removexattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50366r3_rule" do
  title "The audit system must be configured to audit all discretionary access control permission modifications using setxattr."
  desc  "<VulnDiscussion>The changing of file permissions could indicate that a user is attempting to gain access to information that would otherwise be disallowed. Auditing DAC modifications can facilitate the identification of patterns of abuse among both authorized and unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=b32[\s]+)(?:.*-S[\s]+setxattr[\s]+)(?:.*-F\s+auid>=500[\s]+)(?:.*-F\s+auid!=(?:-1|4294967295)[\s]+).*-k[\s]+[\S]+[\s]*$/ }
  end
end

control "SV-50369r3_rule" do
  title "The audit system must be configured to audit successful file system mounts."
  desc  "<VulnDiscussion>The unauthorized exportation of data to external media could result in an information leak where classified information, Privacy Act information, and intellectual property could be lost. An audit trail should be created each time a filesystem is mounted to help identify and guard against information loss.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(\-F\s+arch=(b64|b32)\s+)?\-S\s+mount\s+\-F\s+auid>=500\s+\-F\s+auid!=(?:4294967295|-1)\s+\-k\s+[-\w]+\s*$/ }
  end
end

control "SV-50370r1_rule" do
  title "The system must require passwords to contain at least one uppercase alphabetic character."
  desc  "<VulnDiscussion>Requiring a minimum number of uppercase characters makes password guessing attacks more difficult by ensuring a larger search space.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]ucredit=(-?\d+)(?:[\s]|$)/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]ucredit=(-?\d+)(?:[\s]|$)/).flatten.each do |entry|
    describe entry do
      it { should cmp <= -1 }
    end
  end
end

control "SV-50371r1_rule" do
  title "The system must require passwords to contain at least one special character."
  desc  "<VulnDiscussion>Requiring a minimum number of special characters makes password guessing attacks more difficult by ensuring a larger search space.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]ocredit=(-?\d+)(?:[\s]|$)/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]ocredit=(-?\d+)(?:[\s]|$)/).flatten.each do |entry|
    describe entry do
      it { should cmp <= -1 }
    end
  end
end

control "SV-50372r2_rule" do
  title "The system must require passwords to contain at least one lower-case alphabetic character."
  desc  "<VulnDiscussion>Requiring a minimum number of lower-case characters makes password guessing attacks more difficult by ensuring a larger search space.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]lcredit=(-?\d+)(?:[\s]|$)/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]lcredit=(-?\d+)(?:[\s]|$)/).flatten.each do |entry|
    describe entry do
      it { should cmp <= -1 }
    end
  end
end

control "SV-50373r2_rule" do
  title "The system must require at least eight characters be changed between the old and new passwords during a password change."
  desc  "<VulnDiscussion>Requiring a minimum number of different characters during password changes ensures that newly changed passwords should not resemble previously compromised ones. Note that passwords which are changed on compromised systems will still be compromised, however.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]difok=(-?\d+)(?:[\s]|$)/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^[\s]*password[\s]+(?:(?:required)|(?:requisite))[\s]+[\w_\.\-=\s]+[\s]difok=(-?\d+)(?:[\s]|$)/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 8 }
    end
  end
end

control "SV-50374r4_rule" do
  title "The system must disable accounts after three consecutive unsuccessful logon attempts."
  desc  "<VulnDiscussion>Locking out user accounts after a number of incorrect attempts prevents direct password guessing attacks.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 3 }
    end
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 3 }
    end
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*deny=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 3 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*deny=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 3 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
end

control "SV-50375r2_rule" do
  title "The system must use a FIPS 140-2 approved cryptographic hashing algorithm for generating account password hashes (system-auth)."
  desc  "<VulnDiscussion>Using a stronger hashing algorithm makes password cracking attacks more difficult.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^[\s]*password[\s]+sufficient[\s]+pam_unix\.so[\s]+.*sha512.*$/ }
  end
  describe file("/etc/pam.d/system-auth-ac") do
    its("content") { should match /^[\s]*password[\s]+sufficient[\s]+pam_unix\.so[\s]+.*sha512.*$/ }
  end
end

control "SV-50376r4_rule" do
  title "The audit system must be configured to audit user deletions of files and programs."
  desc  "<VulnDiscussion>Auditing file deletions will create an audit trail for files that are removed from the system. The audit trail could aid in system troubleshooting, as well as detecting malicious processes that attempt to delete log files to conceal their presence.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+rmdir\s+.*\-F\s+auid>=500\s+\-F\s+auid!=(?:(?:-1)|(?:4294967295))\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+unlink\s+.*\-F\s+auid>=500\s+\-F\s+auid!=(?:(?:-1)|(?:4294967295))\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+unlinkat\s+.*\-F\s+auid>=500\s+\-F\s+auid!=(?:(?:-1)|(?:4294967295))\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+rename\s+.*\-F\s+auid>=500\s+\-F\s+auid!=(?:(?:-1)|(?:4294967295))\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+renameat\s+.*\-F\s+auid>=500\s+\-F\s+auid!=(?:(?:-1)|(?:4294967295))\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+rmdir\s+.*\-F\s+auid=0\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+unlink\s+.*\-F\s+auid=0\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+unlinkat\s+.*\-F\s+auid=0\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+rename\s+.*\-F\s+auid=0\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)\s+(?:\-F\s+arch=(?:(?:b64)|(?:b32))\s+)?.*\-S\s+renameat\s+.*\-F\s+auid=0\s+\-k\s+[-\w]+\s*$/ }
  end
end

control "SV-50377r1_rule" do
  title "The system must use a FIPS 140-2 approved cryptographic hashing algorithm for generating account password hashes (login.defs)."
  desc  "<VulnDiscussion>Using a stronger hashing algorithm makes password cracking attacks more difficult.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^[\s]*ENCRYPT_METHOD[\s]+SHA512[\s]*$/ }
  end
end

control "SV-50378r1_rule" do
  title "The system must use a FIPS 140-2 approved cryptographic hashing algorithm for generating account password hashes (libuser.conf)."
  desc  "<VulnDiscussion>Using a stronger hashing algorithm makes password cracking attacks more difficult.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/libuser.conf") do
    its("content") { should match /^[\s]*crypt_style[\s]+=[\s]+(?i)sha512[\s]*$/ }
  end
end

control "SV-50379r2_rule" do
  title "The audit system must be configured to audit changes to the /etc/sudoers file."
  desc  "<VulnDiscussion>The actions taken by system administrators should be audited to keep a record of what was executed on the system, as well as, for accountability purposes.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/etc\/sudoers\s+\-p\s+wa\s+\-k\s+[-\w]+\s*$/ }
  end
end

control "SV-50380r2_rule" do
  title "The system boot loader configuration file(s) must be owned by root."
  desc  "<VulnDiscussion>Only root should be able to modify important boot parameters.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    it { should exist }
  end
  describe file("/boot/grub/grub.conf") do
    its("uid") { should cmp 0 }
  end
  describe file("/boot/efi/EFI/redhat/grub.conf") do
    it { should exist }
  end
  describe file("/boot/efi/EFI/redhat/grub.conf") do
    its("uid") { should cmp 0 }
  end
end

control "SV-50381r2_rule" do
  title "The audit system must be configured to audit the loading and unloading of dynamic kernel modules."
  desc  "<VulnDiscussion>The addition/removal of kernel modules can be used to alter the behavior of the kernel and potentially introduce malicious code into kernel space. It is important to have an audit trail of modules that have been introduced into the kernel.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/sbin\/insmod\s+\-p\s+x\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/sbin\/rmmod\s+\-p\s+x\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^\-w\s+\/sbin\/modprobe\s+\-p\s+x\s+\-k\s+[-\w]+\s*$/ }
  end
  describe file("/etc/audit/audit.rules") do
    its("content") { should match /^[\s]*-a[\s](?:always,exit|exit,always)+(?:.*-F[\s]+arch=(?:(?:b64)|(?:b32))\s+)?\-S\s+init_module\s+\-S\s+delete_module\s+\-k\s+[-\w]+\s*$/ }
  end
end

control "SV-50382r2_rule" do
  title "The system boot loader configuration file(s) must be group-owned by root."
  desc  "<VulnDiscussion>The \"root\" group is a highly-privileged group. Furthermore, the group-owner of this file should not have any access privileges anyway.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    it { should exist }
  end
  describe file("/boot/grub/grub.conf") do
    its("gid") { should cmp 0 }
  end
  describe file("/boot/efi/EFI/redhat/grub.conf") do
    it { should exist }
  end
  describe file("/boot/efi/EFI/redhat/grub.conf") do
    its("gid") { should cmp 0 }
  end
end

control "SV-50383r2_rule" do
  title "The xinetd service must be disabled if no network services utilizing it are enabled."
  desc  "<VulnDiscussion>The xinetd service provides a dedicated listener service for some programs, which is no longer necessary for commonly-used network services. Disabling it ensures that these uncommon services are not running, and also prevents attacks against xinetd itself.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50384r3_rule" do
  title "The system boot loader configuration file(s) must have mode 0600 or less permissive."
  desc  "<VulnDiscussion>Proper permissions ensure that only the root user can modify important boot parameters.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    it { should exist }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_executable.by "group" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_readable.by "group" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_writable.by "group" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_executable.by "other" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_readable.by "other" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_writable.by "other" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should_not be_executable.by "owner" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should be_readable.by "owner" }
  end
  describe file("/boot/grub/grub.conf") do
    it { should be_writable.by "owner" }
  end
end

control "SV-50385r1_rule" do
  title "The xinetd service must be uninstalled if no network services utilizing it are enabled."
  desc  "<VulnDiscussion>Removing the \"xinetd\" package decreases the risk of the xinetd service's accidental (or intentional) activation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("xinetd") do
    it { should_not be_installed }
  end
end

control "SV-50386r3_rule" do
  title "The system boot loader must require authentication."
  desc  "<VulnDiscussion>Password protection on the boot loader configuration ensures users with physical access cannot trivially alter important bootloader settings. These include which kernel to use, and whether to enter single-user mode.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    its("content") { should match /^\s*password\s+--encrypted\s+.*/ }
  end
end

control "SV-50387r1_rule" do
  title "The system must require authentication upon booting into single-user and maintenance modes."
  desc  "<VulnDiscussion>This prevents attackers with physical access from trivially bypassing security on the machine and gaining root access. Such accesses are further prevented by configuring the bootloader password.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/sysconfig/init") do
    its("content") { should match /^SINGLE=\/sbin\/sulogin[\s]*/ }
  end
end

control "SV-50388r1_rule" do
  title "The telnet-server package must not be installed."
  desc  "<VulnDiscussion>Removing the \"telnet-server\" package decreases the risk of the unencrypted telnet service's accidental (or intentional) activation.\n\nMitigation:  If the telnet-server package is configured to only allow encrypted sessions, such as with Kerberos or the use of encrypted network tunnels, the risk of exposing sensitive information is mitigated.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("telnet-server") do
    it { should_not be_installed }
  end
end

control "SV-50389r1_rule" do
  title "The system must not permit interactive boot."
  desc  "<VulnDiscussion>Using interactive boot, the console user could disable auditing, firewalls, or other services, weakening system security.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/sysconfig/init") do
    its("content") { should match /^[\s]*PROMPT[\s]*=[\s]*no[\s]*$/ }
  end
end

control "SV-50390r2_rule" do
  title "The telnet daemon must not be running."
  desc  "<VulnDiscussion>The telnet protocol uses unencrypted network communication, which means that data from the login session, including passwords and all other information transmitted during the session, can be stolen by eavesdroppers on the network. The telnet protocol is also subject to man-in-the-middle attacks.\n\nMitigation:  If an enabled telnet daemon is configured to only allow encrypted sessions, such as with Kerberos or the use of encrypted network tunnels, the risk of exposing sensitive information is mitigated.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/xinetd.d/telnet") do
    its("content") { should match /^\s*disable\s+=\s+yes\s*$/ }
  end
end

control "SV-50391r1_rule" do
  title "The system must allow locking of the console screen in text mode."
  desc  "<VulnDiscussion>Installing \"screen\" ensures a console locking capability is available for users who may need to suspend console logins.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("screen") do
    it { should be_installed }
  end
end

control "SV-50392r1_rule" do
  title "The rsh-server package must not be installed."
  desc  "<VulnDiscussion>The \"rsh-server\" package provides several obsolete and insecure network services. Removing it decreases the risk of those services' accidental (or intentional) activation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("rsh-server") do
    it { should_not be_installed }
  end
end

control "SV-50393r4_rule" do
  title "The system must require administrator action to unlock an account locked by excessive failed login attempts."
  desc  "<VulnDiscussion>Locking out user accounts after a number of incorrect attempts prevents direct password guessing attacks. Ensuring that an administrator is involved in unlocking locked accounts draws appropriate attention to such situations.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*\s+unlock_time=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*\s+unlock_time=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 604800 }
    end
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*\s+unlock_time=([0-9]+).*$/ }
  end
  file("/etc/pam.d/system-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*\s+unlock_time=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 604800 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*\s+unlock_time=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:required))\s+pam_faillock\.so\s+preauth\s+silent.*\s+unlock_time=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 604800 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*\s+unlock_time=([0-9]+).*$/ }
  end
  file("/etc/pam.d/password-auth").content.to_s.scan(/^\s*auth\s+(?:(?:sufficient)|(?:\[default=die\]))\s+pam_faillock\.so\s+authfail.*\s+unlock_time=([0-9]+).*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 604800 }
    end
  end
  describe file("/etc/pam.d/password-auth") do
    its("content") { should match /^\s*account\s+(?:(?:required))\s+pam_faillock\.so$/ }
  end
end

control "SV-50395r2_rule" do
  title "The rshd service must not be running."
  desc  "<VulnDiscussion>The rsh service uses unencrypted network communications, which means that data from the login session, including passwords and all other information transmitted during the session, can be stolen by eavesdroppers on the network.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/xinetd.d/rsh") do
    its("content") { should match /^\s*disable\s+=\s+yes\s*$/ }
  end
end

control "SV-50399r2_rule" do
  title "The rexecd service must not be running."
  desc  "<VulnDiscussion>The rexec service uses unencrypted network communications, which means that data from the login session, including passwords and all other information transmitted during the session, can be stolen by eavesdroppers on the network.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/xinetd.d/rexec") do
    its("content") { should match /^\s*disable\s+=\s+yes\s*$/ }
  end
end

control "SV-50401r2_rule" do
  title "The system must not send ICMPv4 redirects by default."
  desc  "<VulnDiscussion>Sending ICMP redirects permits the system to instruct other systems to update their routing information. The ability to send ICMP redirects is only appropriate for systems acting as routers.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.default.send_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.default.send_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.default.send_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50402r2_rule" do
  title "The system must not send ICMPv4 redirects from any interface."
  desc  "<VulnDiscussion>Sending ICMP redirects permits the system to instruct other systems to update their routing information. The ability to send ICMP redirects is only appropriate for systems acting as routers.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe kernel_parameter("net.ipv4.conf.all.send_redirects") do
    its("value") { should_not be_nil }
  end
  describe kernel_parameter("net.ipv4.conf.all.send_redirects") do
    its("value") { should eq 0 }
  end
  describe file("/etc/sysctl.conf") do
    its("content") { should match /^[\s]*net.ipv4.conf.all.send_redirects[\s]*=[\s]*0[\s]*$/ }
  end
end

control "SV-50403r2_rule" do
  title "The rlogind service must not be running."
  desc  "<VulnDiscussion>The rlogin service uses unencrypted network communications, which means that data from the login session, including passwords and all other information transmitted during the session, can be stolen by eavesdroppers on the network.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/xinetd.d/rlogin") do
    its("content") { should match /^\s*disable\s+=\s+yes\s*$/ }
  end
end

control "SV-50404r1_rule" do
  title "The ypserv package must not be installed."
  desc  "<VulnDiscussion>Removing the \"ypserv\" package decreases the risk of the accidental (or intentional) activation of NIS or NIS+ services.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("ypserv") do
    it { should_not be_installed }
  end
end

control "SV-50405r2_rule" do
  title "The ypbind service must not be running."
  desc  "<VulnDiscussion>Disabling the \"ypbind\" service ensures the system is not acting as a client in a NIS or NIS+ domain.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50406r2_rule" do
  title "The cron service must be running."
  desc  "<VulnDiscussion>Due to its usage for maintenance and security-supporting tasks, enabling the cron daemon is essential.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50407r2_rule" do
  title "The tftp-server package must not be installed unless required."
  desc  "<VulnDiscussion>Removing the \"tftp-server\" package decreases the risk of the accidental (or intentional) activation of tftp services.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("tftp-server") do
    it { should_not be_installed }
  end
end

control "SV-50408r1_rule" do
  title "The SSH daemon must be configured to use only the SSHv2 protocol."
  desc  "<VulnDiscussion>SSH protocol version 1 suffers from design flaws that result in security vulnerabilities and should not be used.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^[\s]*(?i)Protocol[\s]+2[\s]*$/ }
  end
end

control "SV-50409r1_rule" do
  title "The SSH daemon must set a timeout interval on idle sessions."
  desc  "<VulnDiscussion>Causing idle users to be automatically logged out guards against compromises one system leading trivially to compromises on another.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^[\s]*(?i)ClientAliveInterval[\s]+(\d+)[\s]*$/ }
  end
  file("/etc/ssh/sshd_config").content.to_s.scan(/^[\s]*(?i)ClientAliveInterval[\s]+(\d+)[\s]*$/).flatten.each do |entry|
    describe entry do
      it { should cmp <= 900 }
    end
  end
end

control "SV-50411r1_rule" do
  title "The SSH daemon must set a timeout count on idle sessions."
  desc  "<VulnDiscussion>This ensures a user login will be terminated as soon as the \"ClientAliveCountMax\" is reached.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^[\s]*(?i)ClientAliveCountMax[\s]+([\d]+)[\s]*$/ }
  end
  file("/etc/ssh/sshd_config").content.to_s.scan(/^[\s]*(?i)ClientAliveCountMax[\s]+([\d]+)[\s]*$/).flatten.each do |entry|
    describe entry do
      it { should cmp == 0 }
    end
  end
end

control "SV-50412r1_rule" do
  title "The SSH daemon must ignore .rhosts files."
  desc  "<VulnDiscussion>SSH trust relationships mean a compromise on one host can allow an attacker to move trivially to other hosts.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should_not match /^[\s]*(?i)IgnoreRhosts[\s]+no[\s]*$/ }
  end
end

control "SV-50413r1_rule" do
  title "The SSH daemon must not allow host-based authentication."
  desc  "<VulnDiscussion>SSH trust relationships mean a compromise on one host can allow an attacker to move trivially to other hosts.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should_not match /^[\s]*(?i)HostbasedAuthentication[\s]+yes[\s]*$/ }
  end
end

control "SV-50414r1_rule" do
  title "The system must not permit root logins using remote access programs such as ssh."
  desc  "<VulnDiscussion>Permitting direct root login reduces auditable information about who ran privileged commands on the system and also allows direct attack attempts on root's password.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^\s*[Pp][Ee][Rr][Mm][Ii][Tt][Rr][Oo][Oo][Tt][Ll][Oo][Gg][Ii][Nn]\s+(\S+)/ }
  end
  file("/etc/ssh/sshd_config").content.to_s.scan(/^\s*[Pp][Ee][Rr][Mm][Ii][Tt][Rr][Oo][Oo][Tt][Ll][Oo][Gg][Ii][Nn]\s+(\S+)/).flatten.each do |entry|
    describe entry do
      it { should eq "no" }
    end
  end
end

control "SV-50415r1_rule" do
  title "The SSH daemon must not allow authentication using an empty password."
  desc  "<VulnDiscussion>Configuring this setting for the SSH daemon provides additional assurance that remote login via SSH will require a password, even in the event of misconfiguration elsewhere.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should_not match /^[\s]*(?i)PermitEmptyPasswords(?-i)[\s]+yes[\s]*(?:|(?:#.*))?$/ }
  end
end

control "SV-50416r1_rule" do
  title "The SSH daemon must be configured with the Department of Defense (DoD) login banner."
  desc  "<VulnDiscussion>The warning message reinforces policy awareness during the logon process and facilitates possible legal action against attackers. Alternatively, systems whose ownership should not be obvious should ensure usage of a banner that does not provide easy attribution.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^[\s]*(?i)Banner(?-i)[\s]+\/etc\/issue[\s]*$/ }
  end
end

control "SV-50417r1_rule" do
  title "The SSH daemon must not permit user environment settings."
  desc  "<VulnDiscussion>SSH environment options potentially allow users to bypass access restriction in some configurations.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ssh/sshd_config") do
    its("content") { should match /^[\s]*(?i)PermitUserEnvironment[\s]+no[\s]*$/ }
  end
end

control "SV-50419r2_rule" do
  title "The avahi service must be disabled."
  desc  "<VulnDiscussion>Because the Avahi daemon service keeps an open network port, it is subject to network attacks. Its functionality is convenient but is only appropriate if the local network can be trusted.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe service("avahi-daemon").runlevels(/0/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/1/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/2/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/3/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/4/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/5/) do
    it { should be_disabled }
  end
  describe service("avahi-daemon").runlevels(/6/) do
    it { should be_disabled }
  end
end

control "SV-50421r1_rule" do
  title "The system clock must be synchronized continuously, or at least daily."
  desc  "<VulnDiscussion>Enabling the \"ntpd\" service ensures that the \"ntpd\" service will be running and that the system will synchronize its time to any servers specified. This is important whether the system is configured to be a client (and synchronize only its own clock) or it is also acting as an NTP server to other systems. Synchronizing time is essential for authentication services such as Kerberos, but it is also important for maintaining accurate logs and auditing possible security breaches.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50422r1_rule" do
  title "The system clock must be synchronized to an authoritative DoD time source."
  desc  "<VulnDiscussion>Synchronizing with an NTP server makes it possible to collate system logs from multiple sources or correlate computer events with real time events. Using a trusted NTP server provided by your organization is recommended.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/ntp.conf") do
    its("content") { should match /^[\s]*server[\s]+.+$/ }
  end
end

control "SV-50423r2_rule" do
  title "Mail relaying must be restricted."
  desc  "<VulnDiscussion>This ensures \"postfix\" accepts mail messages (such as cron job reports) from the local system only, and not from the network, which protects it from network attack.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/postfix/main.cf") do
    its("content") { should match /^[\s]*inet_interfaces[\s]*=[\s]*localhost[\s]*$/ }
  end
end

control "SV-50428r1_rule" do
  title "The openldap-servers package must not be installed unless required."
  desc  "<VulnDiscussion>Unnecessary packages should not be installed to decrease the attack surface of the system.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("openldap-servers") do
    it { should_not be_installed }
  end
end

control "SV-50430r3_rule" do
  title "The graphical desktop environment must set the idle timeout to no more than 15 minutes."
  desc  "<VulnDiscussion>Setting the idle delay controls when the screensaver will start, and can be combined with screen locking to prevent access from passersby.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
end

control "SV-50431r3_rule" do
  title "The graphical desktop environment must automatically lock after 15 minutes of inactivity and the system must require user reauthentication to unlock the environment."
  desc  "<VulnDiscussion>Enabling idle activation of the screen saver ensures the screensaver will be activated after the idle delay. Applications requiring continuous, real-time screen display (such as network management products) require the login session does not have administrator rights and the display station is located in a controlled-access area.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
end

control "SV-50434r1_rule" do
  title "The system must set a maximum audit log file size."
  desc  "<VulnDiscussion>The total storage for audit log files must be large enough to retain log information over the period required. This is a function of the maximum log file size and the number of logs retained.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/auditd.conf") do
    its("content") { should match /^max_log_file\s*=\s*(\d+)\s*$/ }
  end
  file("/etc/audit/auditd.conf").content.to_s.scan(/^max_log_file\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 6 }
    end
  end
end

control "SV-50436r3_rule" do
  title "The audit system must be configured to audit all attempts to alter system time through adjtimex."
  desc  "<VulnDiscussion>Arbitrary changes to the system time can be used to obfuscate nefarious activities in log files, as well as to confuse network services that are highly dependent upon an accurate system time (such as sshd). All changes to the system time should be audited.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50437r1_rule" do
  title "The system must retain enough rotated audit logs to cover the required log retention period."
  desc  "<VulnDiscussion>The total storage for audit log files must be large enough to retain log information over the period required. This is a function of the maximum log file size and the number of logs retained.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/auditd.conf") do
    its("content") { should match /^num_logs\s*=\s*(\d+)\s*$/ }
  end
  file("/etc/audit/auditd.conf").content.to_s.scan(/^num_logs\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp >= 5 }
    end
  end
end

control "SV-50439r3_rule" do
  title "The graphical desktop environment must have automatic lock enabled."
  desc  "<VulnDiscussion>Enabling the activation of the screen lock after an idle period ensures password entry will be required in order to access the system, preventing access by passersby.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
end

control "SV-50440r3_rule" do
  title "The system must display a publicly-viewable pattern during a graphical desktop environment session lock."
  desc  "<VulnDiscussion>Setting the screensaver mode to blank-only conceals the contents of the display from passersby.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
end

control "SV-50441r2_rule" do
  title "The Automatic Bug Reporting Tool (abrtd) service must not be running."
  desc  "<VulnDiscussion>Mishandling crash data could expose sensitive information about vulnerabilities in software executing on the local machine, as well as sensitive information from within a process's address space or registers.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50442r2_rule" do
  title "The atd service must be disabled."
  desc  "<VulnDiscussion>The \"atd\" service could be used by an unsophisticated insider to carry out activities outside of a normal login session, which could complicate accountability. Furthermore, the need to schedule tasks with \"at\" or \"batch\" is not common.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50443r1_rule" do
  title "The system default umask for daemons must be 027 or 022."
  desc  "<VulnDiscussion>The umask influences the permissions assigned to files created by a process at run time. An unnecessarily permissive umask could result in files being created with insecure permissions.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/rc.d/init.d/functions") do
    its("content") { should match /^\s*umask\s+([^#\s]*)/ }
  end
  file("/etc/rc.d/init.d/functions").content.to_s.scan(/^\s*umask\s+([^#\s]*)/).flatten.each do |entry|
    describe entry do
      it { should cmp /^0?(022|027)$/ }
    end
  end
end

control "SV-50445r2_rule" do
  title "The ntpdate service must not be running."
  desc  "<VulnDiscussion>The \"ntpdate\" service may only be suitable for systems which are rebooted frequently enough that clock drift does not cause problems between reboots. In any event, the functionality of the ntpdate service is now available in the ntpd program and should be considered deprecated.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50446r1_rule" do
  title "The system default umask in /etc/login.defs must be 077."
  desc  "<VulnDiscussion>The umask value influences the permissions assigned to files when they are created. A misconfigured umask value could result in files with excessive permissions that can be read and/or written to by unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/login.defs") do
    its("content") { should match /^[\s]*UMASK[\s]+([^#\s]*)/ }
  end
  file("/etc/login.defs").content.to_s.scan(/^[\s]*UMASK[\s]+([^#\s]*)/).flatten.each do |entry|
    describe entry do
      it { should eq "077" }
    end
  end
end

control "SV-50447r2_rule" do
  title "The oddjobd service must not be running."
  desc  "<VulnDiscussion>The \"oddjobd\" service may provide necessary functionality in some environments but it can be disabled if it is not needed. Execution of tasks by privileged programs, on behalf of unprivileged ones, has traditionally been a source of privilege escalation security issues.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50448r1_rule" do
  title "The system default umask in /etc/profile must be 077."
  desc  "<VulnDiscussion>The umask value influences the permissions assigned to files when they are created. A misconfigured umask value could result in files with excessive permissions that can be read and/or written to by unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/profile") do
    its("content") { should match /^[\s]*umask[\s]+([^#\s]*)/ }
  end
  file("/etc/profile").content.to_s.scan(/^[\s]*umask[\s]+([^#\s]*)/).flatten.each do |entry|
    describe entry do
      it { should eq "077" }
    end
  end
end

control "SV-50449r2_rule" do
  title "The qpidd service must not be running."
  desc  "<VulnDiscussion>The qpidd service is automatically installed when the \"base\" package selection is selected during installation. The qpidd service listens for network connections which increases the attack surface of the system. If the system is not intended to receive AMQP traffic then the \"qpidd\" service is not needed and should be disabled or removed.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50450r1_rule" do
  title "The system default umask for the csh shell must be 077."
  desc  "<VulnDiscussion>The umask value influences the permissions assigned to files when they are created. A misconfigured umask value could result in files with excessive permissions that can be read and/or written to by unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/csh.cshrc") do
    its("content") { should match /^[\s]*umask[\s]+([^#\s]*)/ }
  end
  file("/etc/csh.cshrc").content.to_s.scan(/^[\s]*umask[\s]+([^#\s]*)/).flatten.each do |entry|
    describe entry do
      it { should eq "077" }
    end
  end
end

control "SV-50451r2_rule" do
  title "The rdisc service must not be running."
  desc  "<VulnDiscussion>General-purpose systems typically have their network and routing information configured statically by a system administrator. Workstations or some special-purpose systems often use DHCP (instead of IRDP) to retrieve dynamic network configuration information.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50452r1_rule" do
  title "The system default umask for the bash shell must be 077."
  desc  "<VulnDiscussion>The umask value influences the permissions assigned to files when they are created. A misconfigured umask value could result in files with excessive permissions that can be read and/or written to by unauthorized users.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/bashrc") do
    its("content") { should match /^[\s]*umask[\s]+([^#\s]*)/ }
  end
  file("/etc/bashrc").content.to_s.scan(/^[\s]*umask[\s]+([^#\s]*)/).flatten.each do |entry|
    describe entry do
      it { should eq "077" }
    end
  end
end

control "SV-50457r1_rule" do
  title "The system must use SMB client signing for connecting to samba servers using smbclient."
  desc  "<VulnDiscussion>Packet signing can prevent man-in-the-middle attacks which modify SMB packets in transit.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/samba/smb.conf") do
    its("content") { should match /^[\s]*client[\s]+signing[\s]*=[\s]*mandatory/ }
  end
end

control "SV-50469r3_rule" do
  title "The x86 Ctrl-Alt-Delete key sequence must be disabled."
  desc  "<VulnDiscussion>A locally logged-in user who presses Ctrl-Alt-Delete, when at the console, can reboot the system. If accidentally pressed, as could happen in the case of mixed OS environment, this can create the risk of short-term loss of availability of systems due to unintentional reboot. In the GNOME graphical environment, risk of unintentional reboot from the Ctrl-Alt-Delete sequence is reduced because the user will be prompted before any action is taken.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/init/control-alt-delete.override") do
    its("content") { should match /^\s*exec \/usr\/bin\/logger -p security.info "Ctrl-Alt-Delete pressed"\s*$/ }
  end
end

control "SV-50470r1_rule" do
  title "The postfix service must be enabled for mail delivery."
  desc  "<VulnDiscussion>Local mail delivery is essential to some system maintenance and notification tasks.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "Tests could not be loaded from SCAP file." do
    skip "Tests could not be loaded from SCAP file."
  end
end

control "SV-50472r1_rule" do
  title "The sendmail package must be removed."
  desc  "<VulnDiscussion>The sendmail software was not developed with security in mind and its design prevents it from being effectively contained by SELinux. Postfix should be used instead.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("sendmail") do
    it { should_not be_installed }
  end
end

control "SV-50473r2_rule" do
  title "The netconsole service must be disabled unless required."
  desc  "<VulnDiscussion>The \"netconsole\" service is not necessary unless there is a need to debug kernel panics, which is not common.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe service("netconsole").runlevels(/0/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/1/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/2/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/3/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/4/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/5/) do
    it { should be_disabled }
  end
  describe service("netconsole").runlevels(/6/) do
    it { should be_disabled }
  end
end

control "SV-50475r1_rule" do
  title "X Windows must not be enabled unless required."
  desc  "<VulnDiscussion>Unnecessary services should be disabled to decrease the attack surface of the system.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/inittab") do
    its("content") { should match /^[\s]*id:3:initdefault:[\s]*$/ }
  end
end

control "SV-50476r2_rule" do
  title "Process core dumps must be disabled unless needed."
  desc  "<VulnDiscussion>A core dump includes a memory image taken at the time the operating system terminates an application. The memory image could contain sensitive data and is generally useful only for developers trying to debug problems.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource textfilecontent54_test could not be loaded: Don't understand SCAP::OVAL::Objects: textfilecontent54_object/set" do
    skip "SCAP oval resource textfilecontent54_test could not be loaded: Don't understand SCAP::OVAL::Objects: textfilecontent54_object/set"
  end
end

control "SV-50477r2_rule" do
  title "The xorg-x11-server-common (X Windows) package must not be installed, unless required."
  desc  "<VulnDiscussion>Unnecessary packages should not be installed to decrease the attack surface of the system.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("xorg-x11-server-common") do
    it { should_not be_installed }
  end
end

control "SV-50478r1_rule" do
  title "The NFS server must not have the insecure file locking option enabled."
  desc  "<VulnDiscussion>Allowing insecure file locking could allow for sensitive data to be viewed or edited by an unauthorized user.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/exports") do
    its("content") { should_not match /^[^#]*insecure_locks.*$/ }
  end
end

control "SV-50480r2_rule" do
  title "The DHCP client must be disabled if not needed."
  desc  "<VulnDiscussion>DHCP relies on trusting the local network. If the local network is not trusted, then it should not be used. However, the automatic configuration provided by DHCP is commonly used and the alternative, manual configuration, presents an unacceptable burden in many circumstances.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  command("find /etc/sysconfig/network-scripts -type f -regex .\\*/ifcfg-.\\*").stdout.split.each do |entry|
    describe file(entry) do
      its("content") { should match /^[\s]*BOOTPROTO[\s]*=[\s"]*([^#"\s]*)/ }
    end
  end
end

control "SV-50481r1_rule" do
  title "The audit system must identify staff members to receive notifications of audit log storage volume capacity issues."
  desc  "<VulnDiscussion>Email sent to the root account is typically aliased to the administrators of the system, who can take appropriate action.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/auditd.conf") do
    its("content") { should match /^action_mail_acct\s*=\s*(\S+)\s*$/ }
  end
  file("/etc/audit/auditd.conf").content.to_s.scan(/^action_mail_acct\s*=\s*(\S+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should eq "root" }
    end
  end
end

control "SV-50485r2_rule" do
  title "The system must limit users to 10 simultaneous system logins, or a site-defined number, in accordance with operational requirements."
  desc  "<VulnDiscussion>Limiting simultaneous user logins can insulate the system from denial of service problems caused by excessive logins. Automated login processes operating improperly or maliciously may result in an exceptional number of simultaneous login sessions.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource textfilecontent54_test could not be loaded: Don't understand SCAP::OVAL::Objects: textfilecontent54_object/set" do
    skip "SCAP oval resource textfilecontent54_test could not be loaded: Don't understand SCAP::OVAL::Objects: textfilecontent54_object/set"
  end
end

control "SV-50488r2_rule" do
  title "The system must provide VPN connectivity for communications over untrusted networks."
  desc  "<VulnDiscussion>Providing the ability for remote users or systems to initiate a secure VPN connection protects information when it is transmitted over a wide area network.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe package("openswan") do
    it { should be_installed }
  end
end

control "SV-50489r3_rule" do
  title "A login banner must be displayed immediately prior to, or as part of, graphical desktop environment login prompts."
  desc  "<VulnDiscussion>An appropriate warning message reinforces policy awareness during the logon process and facilitates possible legal action against attackers.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
  describe "SCAP oval resource xmlfilecontent_test is not yet supported." do
    skip "SCAP oval resource xmlfilecontent_test is not yet supported."
  end
end

control "SV-50492r2_rule" do
  title "The Bluetooth service must be disabled."
  desc  "<VulnDiscussion>Disabling the \"bluetooth\" service prevents the system from attempting connections to Bluetooth devices, which entails some security risk. Nevertheless, variation in this risk decision may be expected due to the utility of Bluetooth connectivity and its limited range.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe service("bluetooth").runlevels(/0/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/1/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/2/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/3/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/4/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/5/) do
    it { should be_disabled }
  end
  describe service("bluetooth").runlevels(/6/) do
    it { should be_disabled }
  end
end

control "SV-50493r1_rule" do
  title "Accounts must be locked upon 35 days of inactivity."
  desc  "<VulnDiscussion>Disabling inactive accounts ensures that accounts which may not have been responsibly removed are not available to attackers who may have compromised their credentials.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/default/useradd") do
    its("content") { should match /^\s*INACTIVE\s*=\s*(\d+)\s*$/ }
  end
  file("/etc/default/useradd").content.to_s.scan(/^\s*INACTIVE\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp <= 35 }
    end
  end
  file("/etc/default/useradd").content.to_s.scan(/^\s*INACTIVE\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp > -1 }
    end
  end
end

control "SV-50495r1_rule" do
  title "The operating system must manage information system identifiers for users and devices by disabling the user identifier after an organization defined time period of inactivity."
  desc  "<VulnDiscussion>Disabling inactive accounts ensures that accounts which may not have been responsibly removed are not available to attackers who may have compromised their credentials.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/default/useradd") do
    its("content") { should match /^\s*INACTIVE\s*=\s*(\d+)\s*$/ }
  end
  file("/etc/default/useradd").content.to_s.scan(/^\s*INACTIVE\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp <= 35 }
    end
  end
  file("/etc/default/useradd").content.to_s.scan(/^\s*INACTIVE\s*=\s*(\d+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp > -1 }
    end
  end
end

control "SV-50502r1_rule" do
  title "The TFTP daemon must operate in secure mode which provides access only to a single directory on the host file system."
  desc  "<VulnDiscussion>Using the \"-s\" option causes the TFTP service to only serve files from the given directory. Serving files from an intentionally specified directory reduces the risk of sharing files which should remain private.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/xinetd.d/tftp") do
    its("content") { should match /^[\s]*server_args[\s]+=[\s]+\-s[\s]+.+$/ }
  end
end

control "SV-65547r2_rule" do
  title "The system must use a Linux Security Module at boot time."
  desc  "<VulnDiscussion>Disabling a major host protection feature, such as SELinux, at boot time prevents it from confining system services at boot time. Further, it increases the chances that it will remain off during system operation.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/boot/grub/grub.conf") do
    its("content") { should_not match /^[\s]*kernel[\s]+.*(selinux|enforcing)=0.*$/ }
  end
end

control "SV-65573r1_rule" do
  title "The system must use a Linux Security Module configured to enforce limits on system services."
  desc  "<VulnDiscussion>Setting the SELinux state to enforcing ensures SELinux is able to confine potentially compromised processes to the security policy, which is designed to prevent them from causing damage to the system or further elevating their privileges. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/selinux/config") do
    its("content") { should match /^[\s]*SELINUX[\s]*=[\s]*(.*)[\s]*$/ }
  end
  file("/etc/selinux/config").content.to_s.scan(/^[\s]*SELINUX[\s]*=[\s]*(.*)[\s]*$/).flatten.each do |entry|
    describe entry do
      it { should eq "enforcing" }
    end
  end
end

control "SV-65579r1_rule" do
  title "The system must use a Linux Security Module configured to limit the privileges of system services."
  desc  "<VulnDiscussion>Setting the SELinux policy to \"targeted\" or a more specialized policy ensures the system will confine processes that are likely to be targeted for exploitation, such as network or system services. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/selinux/config") do
    its("content") { should match /^[\s]*SELINUXTYPE[\s]*=[\s]*([^\s]*)/ }
  end
  file("/etc/selinux/config").content.to_s.scan(/^[\s]*SELINUXTYPE[\s]*=[\s]*([^\s]*)/).flatten.each do |entry|
    describe entry do
      it { should eq "targeted" }
    end
  end
end

control "SV-66089r1_rule" do
  title "The operating system, upon successful logon/access, must display to the user the number of unsuccessful logon/access attempts since the last successful logon/access."
  desc  "<VulnDiscussion>Users need to be aware of activity that occurs regarding their account. Providing users with information regarding the number of unsuccessful attempts that were made to login to their account allows the user to determine if any unauthorized activity has occurred and gives them an opportunity to notify administrators. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/pam.d/system-auth") do
    its("content") { should match /^\s*session\s+(required|requisite)?\s+pam_lastlog.so[\s\w\d\=]+showfailed/ }
  end
end

control "SV-68627r3_rule" do
  title "The audit system must switch the system to single-user mode when available audit storage volume becomes dangerously low."
  desc  "<VulnDiscussion>Administrators should be made aware of an inability to record audit records. If a separate partition or logical volume of adequate size is used, running low on space for audit records should never occur. </VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>"
  impact 10.0
  describe file("/etc/audit/auditd.conf") do
    its("content") { should match /^\s*admin_space_left_action[ ]+=[ ]+(\S+)\s*$/ }
  end
  file("/etc/audit/auditd.conf").content.to_s.scan(/^\s*admin_space_left_action[ ]+=[ ]+(\S+)\s*$/).flatten.each do |entry|
    describe entry do
      it { should cmp /^(?:[sS][iI][nN][gG][lL][eE]|[sS][uU][sS][pP][eE][nN][dD]|[hH][aA][lL][tT])$/ }
    end
  end
end
