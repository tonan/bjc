# attr_catalinabase = attribute('catalina.base',{
#   title: '$CATALINA_BASE',
#   default: '/usr/share/tomcat6',
# })
#
# attr_catalinahome = attribute('catalina.home',{
#   title: '$CATALINA_HOME',
#   default: '/usr/share/tomcat6',
# })
#
# attr_tomcatfileuser = attribute('tomcat.fileuser',{
#   title: 'Tomcat file resource owner user ID',
#   default: 'tomcat',
# })
#
# attr_tomcatfilegroup = attribute('tomcat.filegroup',{
#   title: 'Tomcat file resource group ID ',
#   default: 'tomcat',
# })

attr_catalinabase = '/usr/share/tomcat6'
attr_catalinahome = '/usr/share/tomcat6'
attr_tomcatfileuser = 'tomcat'
attr_tomcatfilegroup = 'tomcat'

control "disable-unused-connectors" do
  title "Disable Unused Connectors"
  desc  "Description: The default installation of Tomcat includes connectors with default settings. These are traditionally set up for convenience. It is best to remove these connectors and develop connectors from scratch, only enabling exactly what is needed.  Rationale: Improperly configured or unnecessarily installed Connectors may lead to a security exposure.  Level: 1 Audit: Perform the following to identify configured Connectors:  1. Execute the following command to find configured Connectors. Ensure only those required are present and not commented out:  $ grep \"Connector\" $CATALINA_HOME/conf/server.xml \n                         Default Value: $CATALINA_HOME/conf/server.xml, has the following connectors defined by default: * A non-SSL Connector bound to port 8080 * An AJP 1.3 Connector bound to port 8009  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/connectors.html"
  impact 0.0
end

control "disable-client-facing-stack-traces" do
  title "Disable client facing Stack Traces"
  desc  "Description: When a runtime error occurs during request processing, Apache Tomcat will display debugging information to the requestor. It is recommended that such debug information be withheld from the requestor.  Rationale: Debugging information, such as that found in call stacks, often contains sensitive information that may useful to an attacker. By preventing Tomcat from providing this information, the risk of leaking sensitive information to a potential attacker is reduced.  Level: 1 Audit: Perform the following to determine if Tomcat is configured to prevent sending debug information to the requestor  1. Ensure an <error-page> element is defined in$ CATALINA_HOME/conf/web.xml. 2. Ensure the <error-page> element has an <exception-type> child element with a value of java.lang.Throwable. 3. Ensure the <error-page> element has a <location> child element.  Note: Perform the above for each application hosted within Tomcat. Per application instances of web.xml can be found at $CATALINA_HOME/webapps/<APP_NAME>/WEB-INF/web.xml \n                         Default Value: Tomcat's default configuration does not include an <error-page> element in $CATALINA_HOME/conf/web.xml. Therefore, Tomcat will provide debug information to the requestor by default.  References: http://tomcat.apache.org/tomcat-5.5-doc/catalina/docs/api/org/apache/catalina/deploy/ErrorPage.html 1."
  impact 1.0
  describe file("#{attr_catalinabase}/conf/web.xml") do
    its("content") { should match(/<exception-type>\s*java.lang.Throwable\s*<\/exception-type>/) }
  end
  describe file("#{attr_catalinabase}/conf/web.xml") do
    its("content") { should match(/<error-page>/) }
  end
end

control "turn-off-trace" do
  title "Turn off TRACE"
  desc  "Description: The HTTP TRACE verb provides debugging and diagnostics information for a given request.  Rationale: Diagnostic information, such as that found in the response to a TRACE request, often contains sensitive information that may useful to an attacker. By preventing Tomcat from providing this information, the risk of leaking sensitive information to a potential attacker is reduced.  Level: 1 Audit: Perform the following to determine if the server platform, as advertised in the HTTP Server header, has been changed:  1. Locate all Connector elements in $CATALINA_HOME/conf/server.xml. 2. Ensure each Connector does not have a getTrace attribute or if the getTrace attribute is not set true.  Note: Perform the above for each application hosted within Tomcat. Per application instances of web.xml can be found at $CATALINA_HOME/webapps/<APP_NAME>/WEB-INF/web.xml \n                         Default Value: Tomcat does not allow the TRACE HTTP verb by default. Tomcat will only allow TRACE if the allowTrace attribute is present and set to true.  References: http://tomcat.apache.org/tomcat-5.5-doc/config/http.html 1."
  impact 1.0
  describe file("#{attr_catalinabase}/conf/web.xml") do
    its("content") { should_not match(/allowTrace\s*=\s*"true"/) }
  end
end

control "set-a-nondeterministic-shutdown-command-value" do
  title "Set a nondeterministic Shutdown command value"
  desc  "Description: Tomcat listens on TCP port 8005 to accept shutdown requests. By connecting to this port and sending the SHUTDOWN command, all applications within Tomcat are halted. The shutdown port is not exposed to the network as it is bound to the loopback interface. It is recommended that a nondeterministic value be set for the shutdown attribute in $CATALINA_HOME/conf/server.xml.  Rationale: Setting the shutdown attribute to a nondeterministic value will prevent malicious local users from shutting down Tomcat.  Level: 1 Audit: Perform the following to determine if the shutdown port is configured to use the default shutdown command:  1. Ensure the shutdown attribute in $CATALINA_HOME/conf/server.xml is not set to SHUTDOWN. $ cd $CATALINA_HOME/conf $ grep 'shutdown[[:space:]]*=[[:space:]]*\"SHUTDOWN\"' server.xml \n                         Default Value: The default value for the shutdown attribute is SHUTDOWN.  References: 1. http://tomcat.apache.org/tomcat-5.5-doc/config/server.html"
  impact 1.0
  describe bash("cat #{attr_catalinabase}/conf/server.xml") do
    its("stdout") { should_not match(/shutdown\s*=\s*"SHUTDOWN"/) }
  end
end

control "restrict-access-to-catalina_home" do
  title "Restrict access to $CATALINA_HOME"
  desc  "Description: $CATALINA_HOME is the environment variable which holds the path to the root Tomcat directory. It is important to protect access to this in order to protect the Tomcat binaries and libraries from unauthorized modification. It is recommended that the ownership of $CATALINA_HOME be tomcat_admin:tomcat. It is also recommended that the permission on $CATALINA_HOME prevent read, write, and execute for the world (o-rwx) and prevent write access to the group (g-w).  Rationale: The security of processes and data that traverse or depend on Tomcat may become compromised if the $CATALINA_HOME is not secured.  Level: 1 Audit: Perform the following to ensure the permission on the $CATALINA_HOME directory prevent unauthorized modification.  $ cd $CATALINA_HOME $ find . -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls  The above command should not emit any output."
  impact 1.0
  describe bash("find #{attr_catalinabase} -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-catalina_base" do
  title "Restrict access to $CATALINA_BASE"
  desc  "Description: $CATALINA_BASE is the environment variable that specifies the base directory which most relative paths are resolved. $CATALINA_BASE is usually used when there is multiple instances of Tomcat running. It is important to protect access to this in order to protect the Tomcat-related binaries and libraries from unauthorized modification. It is recommended that the ownership of $CATALINA_BASE be tomcat_admin:tomcat. It is also recommended that the permission on $CATALINA_BASE prevent read, write, and execute for the world (o-rwx) and prevent write access to the group (g-w).  Rationale: The security of processes and data that traverse or depend on Tomcat may become compromised if the $CATALINA_BASE is not secured.  Level: 1 Audit: Perform the following to ensure the permission on the $CATALINA_BASE directory prevent unauthorized modification.  $ cd $CATALINA_BASE $ find . -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls  The above command should not emit any output."
  impact 1.0
  describe bash("find #{attr_catalinahome} -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-configuration-directory" do
  title "Restrict access to Tomcat configuration directory"
  desc  "Description: The Tomcat $CATALINA_HOME/conf/ directory contains Tomcat configuration files. It is recommended that the ownership of this directory be tomcat_admin:tomcat. It is also recommended that the permissions on this directory prevent read, write, and execute for the world (o-rwx) and prevent write access to the group (g-w).  Rationale: Restricting access to these directories will prevent local users from maliciously or inadvertently altering Tomcat's configuration.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf are securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf # find catalina.policy -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 770."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-logs-directory" do
  title "Restrict access to Tomcat logs directory"
  desc  "Description: The Tomcat $CATALINA_HOME/logs/ directory contains Tomcat logs. It is recommended that the ownership of this directory be tomcat_admin:tomcat. It is also recommended that the permissions on this directory prevent read, write, and execute for the world (o-rwx).  Rationale: Restricting access to these directories will prevent local users from maliciously or inadvertently altering Tomcat's logs.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/logs are securely configured.  1. Change to the location of the $CATALINA_HOME/logs and execute the following: # cd $CATALINA_HOME # find logs -follow -maxdepth 0 \\( -perm –o-rwx! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 770.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/security-manager-howto.html"
  impact 1.0
  describe bash("find #{attr_catalinabase}/logs -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-temp-directory" do
  title "Restrict access to Tomcat temp directory"
  desc  "Description: The Tomcat $CATALINA_HOME/temp/ directory is used by Tomcat to persist temporary information to disk. It is recommended that the ownership of this directory be tomcat_admin:tomcat. It is also recommended that the permissions on this directory prevent read, write, and execute for the world (o-rwx).  Rationale: Restricting access to these directories will prevent local users from maliciously or inadvertently affecting the integrity of Tomcat processes.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/temp are securely configured.  1. Change to the location of the $CATALINA_HOME/temp and execute the following: # cd $CATALINA_HOME # find temp -follow -maxdepth 0 \\( -perm –o-rwx -o ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 770."
  impact 1.0
  describe bash("find #{attr_catalinabase}/temp -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-binaries-directory" do
  title "Restrict access to Tomcat binaries directory"
  desc  "Description: The Tomcat $CATALINA_HOME/bin/ directory contains executes that are part of the Tomcat run-time. It is recommended that the ownership of this directory be tomcat_admin:tomcat. It is also recommended that the permission on $CATALINA_HOME prevent read, write, and execute for the world (o-rwx) and prevent write access to the group (g-w).  Rationale: Restricting access to these directories will prevent local users from maliciously or inadvertently affecting the integrity of Tomcat processes.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/bin are securely configured.  1. Change to the location of the $CATALINA_HOME/bin and execute the following: # cd $CATALINA_HOME # find bin -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 770."
  impact 1.0
  describe bash("find #{attr_catalinabase}/bin -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-web-application-directory" do
  title "Restrict access to Tomcat web application directory"
  desc  "Description: The Tomcat $CATALINA_HOME/webapps directory contains web applications that are deployed through Tomcat. It is recommended that the ownership of this directory be tomcat_admin:tomcat. It is also recommended that the permission on $CATALINA_HOME/webapps prevent read, write, and execute for the world (o-rwx) and prevent write access to the group (g-w).  Rationale: Restricting access to these directories will prevent local users from maliciously or inadvertently affecting the integrity of web applications.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/webapps are securely configured.  1. Change to the location of the $CATALINA_HOME/webapps and execute the following: # cd $CATALINA_HOME # find webapps -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 770."
  impact 1.0
  describe bash("find #{attr_catalinabase}/webapps -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-catalinapolicy" do
  title "Restrict access to Tomcat catalina.policy"
  desc  "Description: The catalina.policy file is used to configure security policies for Tomcat. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Note: Some Tomcat Linux packages, such as the tomcat55 Debian package, cause catalina.policy to be automatically regenerated, at service restart, from individual policy files located in /etc/tomcat55/policy.d. In such scenarios, it is highly recommended that access to the /etc/tomcat55/policy.d directory and its contents be similarly restricted.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/catalina.policy care securely configured.  1. Change to the location of the $CATALINA_HOME/ and execute the following: # cd $CATALINA_HOME/conf/ # find catalina.policy !-follow -maxdepth 0 \\( -perm -o+rwx -o -perm –g+rwx ! -user tomcat_admin -group tomcat -perm /770 \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of catalina.policy is 600.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/security-manager-howto.html"
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/catalina.policy -follow -maxdepth 0 \\( -perm /077 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-catalinaproperties" do
  title "Restrict access to Tomcat catalina.properties"
  desc  "Description: catalina.properties is a Java properties files that contains settings for Tomcat including class loader information, security package lists, and performance properties. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Note: Some Tomcat Linux packages, such as the tomcat55 Debian package, cause catalina.policy to be automatically regenerated, at service restart, from individual policy files located in /etc/tomcat55/policy.d. In such scenarios, it is highly recommended that access to the /etc/tomcat55/policy.d directory and its contents be similarly restricted.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/catalina.properties care securely configured.  1. Change to the location of the $CATALINA_HOME/ and execute the following: # cd $CATALINA_HOME/conf/ # find catalina.properties -follow -maxdepth 0 \\( -perm -o+rwx -o -perm -g+rwx ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 600."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/catalina.properties -follow -maxdepth 0 \\( -perm /077 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-contextxml" do
  title "Restrict access to Tomcat context.xml"
  desc  "Description: The context.xml file is loaded by all web applications and sets certain configuration options. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/context.xml care securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf # find context.xml -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of context.xml are 600."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/context.xml -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-loggingproperties" do
  title "Restrict access to Tomcat logging.properties"
  desc  "Description: logging.properties is a Tomcat files which specifies the logging configuration. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Note: Some Tomcat Linux packages, such as the tomcat55 Debian package, cause catalina.policy to be automatically regenerated, at service restart, from individual policy files located in /etc/tomcat55/policy.d. In such scenarios, it is highly recommended that access to the /etc/tomcat55/policy.d directory and its contents be similarly restricted.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/logging.properties care securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf/ # find logging.properties -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions are 600."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/logging.properties -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-serverxml" do
  title "Restrict access to Tomcat server.xml"
  desc  "Description: server.xml contains Tomcat servlet definitions and configurations. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Note: Some Tomcat Linux packages, such as the tomcat55 Debian package, cause catalina.policy to be automatically regenerated, at service restart, from individual policy files located in /etc/tomcat55/policy.d. In such scenarios, it is highly recommended that access to the /etc/tomcat55/policy.d directory and its contents be similarly restricted.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/server.xml care securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf/ # find server.xml -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 600."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/server.xml -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-tomcat-usersxml" do
  title "Restrict access to Tomcat tomcat-users.xml"
  desc  "Description: tomcat-users.xml contains authentication information for Tomcat applications. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Note: Some Tomcat Linux packages, such as the tomcat55 Debian package, cause catalina.policy to be automatically regenerated, at service restart, from individual policy files located in /etc/tomcat55/policy.d. In such scenarios, it is highly recommended that access to the /etc/tomcat55/policy.d directory and its contents be similarly restricted.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/tomcat-users.xml care securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf/ # find tomcat-users.xml -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of the top-level directories is 600.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/security-manager-howto.html"
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/tomcat-users.xml -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "restrict-access-to-tomcat-webxml" do
  title "Restrict access to Tomcat web.xml"
  desc  "Description: web.xml is a Tomcat configuration file that stores application configuration settings. It is recommended that access to this file has the proper permissions to properly protect from unauthorized changes.  Rationale: Restricting access to this file will prevent local users from maliciously or inadvertently altering Tomcat's security policy.  Level: 1 Audit: Perform the following to determine if the ownership and permissions on $CATALINA_HOME/conf/web.xml care securely configured.  1. Change to the location of the $CATALINA_HOME/conf and execute the following: # cd $CATALINA_HOME/conf/ # find web.xml -follow -maxdepth 0 \\( -perm –o-rwx -o -perm –g-w ! -user tomcat_admin \\) -ls Note: If the ownership and permission are set correctly, no output should be displayed when executing the above command. \n                         Default Value: The default permissions of web.xml is 400."
  impact 1.0
  describe bash("find #{attr_catalinabase}/conf/web.xml -follow -maxdepth 0 \\( -perm /027 -o ! -user #{attr_tomcatfileuser} -o ! -group #{attr_tomcatfilegroup} \\) -ls") do
    its("stdout") { should_not match(/^.*$/) }
  end
end

control "ensure-sslenabled-is-set-to-true-for-sensitive-connectors" do
  title "Ensure SSLEnabled is set to True for Sensitive Connectors"
  desc  "Description: The SSLEnabled setting determines if SSL is enabled for a specific Connector. It is recommended that SSL be utilized for any Connector that sends or receives sensitive information, such as authentication credentials or personal information.  Rationale: The SSLEnabled setting ensures SSL is active, which will in-turn ensure the confidentiality and integrity of sensitive information while in transit. \n                         Level: 1 Audit: Review server.xml and ensure all Connectors sending or receiving sensitive information have the SSLEnabled attribute set to true. \n                         Default Value: SSLEnabled is set to false.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/ssl-howto.html 2. http://tomcat.apache.org/tomcat-5.5-doc/ssl-howto.html 3. http://tomcat.apache.org/tomcat-6.0-doc/config/http.html"
  impact 0.0
end

control "ensure-scheme-is-set-accurately" do
  title "Ensure scheme is set accurately"
  desc  "Description: The scheme attribute is used to indicate to callers of request.getScheme() which scheme is in use by the Connector. Ensure the scheme attribute is set to http for Connectors operating over HTTP. Ensure the scheme attribute is set to https for Connectors operating of HTTPS.  Rationale: Maintaining parity between the scheme in use by the Connector and advertised by request.getScheme() will ensure applications built on Tomcat have an accurate depiction of the context and security guarantees provided to them. \n                         Level: 1 Audit: Review server.xml to ensure the Connector's scheme attribute is set to http for Connectors operating over HTTP. Also ensure the Connector's scheme attribute is set to https for Connectors operating over HTTPS. \n                         Default Value: The scheme attribute is set to http.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/ssl-howto.html 2. http://tomcat.apache.org/tomcat-5.5-doc/ssl-howto.html 3. http://tomcat.apache.org/tomcat-6.0-doc/config/http.html"
  impact 1.0
  describe bash("expr `cat /opt/tomcat/conf/server.xml | sed '/<!--.*-->/d'| sed '/<!--/,/-->/d' | egrep '[[:space:]]*<secure=\\\"true\\\"[[:space:]]*' | wc -l` = `cat /opt/tomcat/conf/server.xml | sed '/<!--.*-->/d'| sed '/<!--/,/-->/d' | egrep '[[:space:]]*scheme=\\\"https\\\"[[:space:]]*'  | wc -l` ") do
    its("exit_status") { should eq 0 }
  end
end

control "ensure-secure-is-set-to-true-only-for-ssl-enabled-connectors" do
  title "Ensure secure is set to true only for SSL-enabled Connectors"
  desc  "Description: The secure attribute is used to convey Connector security status to applications operating over the Connector. This is typically achieved by calling request.isSecure(). Ensure the secure attribute is only set to true for Connectors operating with the SSLEnabled attribute set to true.  Rationale: Accurately reporting the security state of the Connector will help ensure that applications built on Tomcat are not unknowingly relying on security controls that are not in place. \n                         Level: 1 Audit: Review server.xml and ensure the secure attribute is set to true for those Connectors having SSLEnabled set to true. Also, ensure the secure attribute set to false for those Connectors having SSLEnabled set to false. \n                         Default Value: The secure attribute is set to false.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/ssl-howto.html 2. http://tomcat.apache.org/tomcat-5.5-doc/ssl-howto.html 3. http://tomcat.apache.org/tomcat-6.0-doc/config/http.html"
  impact 1.0
  describe bash("expr `cat /opt/tomcat/conf/server.xml | sed '/<!--.*-->/d'| sed '/<!--/,/-->/d' | egrep '[[:space:]]*SSLEnabled=\\\"true\\\"[[:space:]]*' | wc -l` = `cat /opt/tomcat/conf/server.xml | sed '/<!--.*-->/d'| sed '/<!--/,/-->/d' | egrep '[[:space:]]*secure=\\\"true\\\"[[:space:]]*'  | wc -l` ") do
    its("exit_status") { should eq 0 }
  end
end

control "ensure-sslprotocol-is-set-to-tls-for-secure-connectors" do
  title "Ensure sslProtocol is set to TLS for Secure Connectors"
  desc  "Description: The sslProtocol setting determines which protocol Tomcat will use to protect traffic. It is recommended that sslProtocol attribute be set to TLS.  Rationale: The TLS protocol does not contain weaknesses that affect other secure transport protocols, such as SSLv1 or SSLv2. Therefore, TLS is leveraged to protect the confidentiality and integrity of data while in transit. \n                         Level: 1 Audit: Review server.xml to ensure the sslProtocol attribute is set to TLS for all Connectors having SSLEngine set to on. \n                         Default Value: If the sslProtocol attribute is not set, Tomcat will utilize TLS.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/ssl-howto.html 2. http://tomcat.apache.org/tomcat-5.5-doc/ssl-howto.html 3. http://tomcat.apache.org/tomcat-6.0-doc/config/http.html"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should_not match(/sslProtocol\s*=\s*"\s*[^T].*?\s*"/) }
  end
end

control "specify-file-handler-in-loggingproperties-files" do
  title "Specify file handler in logging.properties files"
  desc  "Description: Handlers specify where log messages are sent. Console handlers send log messages to the Java console and File handlers specify logging to a file.  Rationale: Utilizing file handlers will ensure that security event information is persisted to disk.  Level: 1 Audit: Review each application's logging.properties file located in the applications $CATALINA_BASE\\<app name>\\WEB-INF\\classes directory and determine if the file handler properties are set. $ grep handlers \\ $CATALINA_BASE\\<app name>\\WEB-INF\\classes\\logging.properties In the instance where an application specific logging has not been created, the logging.properties file will be located in $CATALINA_BASE\\conf. $ grep handlers $CATALINA_BASE\\conf\\logging.properties \n                         Default Value: No value for new applications by default."
  impact 1.0
  describe bash("find -L #{attr_catalinabase} -name logging.properties | xargs grep org.apache.juli.FileHandler || echo \"fail\"") do
    its("stdout") { should_not match(/^fail$/) }
  end
end

control "ensure-directory-in-contextxml-is-a-secure-location" do
  title "Ensure directory in context.xml is a secure location"
  desc  "Description: The directory attribute tells Tomcat where to store logs. It is recommended that the location pointed to by the directory attribute be secured.  Rationale: Securing the log location will help ensure the integrity and confidentiality of web application activity.  Level: 1 Audit: Review the permissions of the directory specified by the directory setting to ensure the permissions are o-rwx and owned by tomcat_admin:tomcat: # grep directory context.xml # ls –l <log location> \n                         Default Value: Does not exist by default."
  impact 0.0
end

control "ensure-pattern-in-contextxml-is-correct" do
  title "Ensure pattern in context.xml is correct"
  desc  "Description: The pattern setting informs Tomcat what information should be logged. At a minimum, enough information to uniquely identify a request, what was requested, where the requested originated from, and when the request occurred should be logged.  The following will log the request date and time (%t), the requested URL (%U), the remote IP address (%a), the local IP address (%A), the request method (%m), the local port (%p), query string, if present, (%q), and the HTTP status code of the response (%s). pattern=\"%t %U %a %A %m %p %q %s\" \n                         Rationale: The level of logging detail prescribed will assist in identifying correlating security events or incidents.  Level: 1 Audit: Review the pattern settings to ensure it contains all the variables required by the installation.  # grep pattern context.xml \n                         Default Value: Does not exist by default.  Reference: 1. http://tomcat.apache.org/tomcat-5.5-doc/config/valve.html"
  impact 0.0
end

control "ensure-directory-in-loggingproperties-is-a-secure-location" do
  title "Ensure directory in logging.properties is a secure location"
  desc  "Description: The directory attribute tells Tomcat where to store logs. The directory value should be a secure location with restricted access.  Rationale: Securing the log location will help ensure the integrity and confidentiality of web application activity records.  Level: 1 Audit: Review the permissions of the directory specified by the directory setting to ensure the permissions are o-rwx and owned by tomcat_admin:tomcat: # grep directory logging.properties # ls –l <log_location> \n                         Default Value: The directory location is configured to store logs in $CATALINA_BASE/logs."
  impact 0.0
end

control "restrict-runtime-access-to-sensitive-packages" do
  title "Restrict runtime access to sensitive packages"
  desc  "Description: package.access grants or revokes access to listed packages during runtime. It is recommended that application access to certain packages be restricted.  Rationale: Prevent web applications from accessing restricted or unknown packages which may be malicious or dangerous to the application.  Level: 1 Audit: Review package.access list in $CATALINA_BASE/conf/catalina.properties to ensure only allowed packages are defined. \n                         Default Value: The default package.access value within $CATALINA_BASE/conf/catalina.properties is: package.access = sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat., org.apache.jasper"
  impact 0.0
end

control "starting-tomcat-with-security-manager" do
  title "Starting Tomcat with Security Manager"
  desc  "Description: Configure application to run in a sandbox using the Security Manager. The Security Manager restricts what classes Tomcat can access thus protecting your server from mistakes, Trojans, and malicious code.  Rationale: By running Tomcat with the Security Manager, applications are run in a sandbox which can prevent untrusted code from accessing files on the file system.  Level: 1 Audit: Review the start up configuration in /etc/init.d for Tomcat to ascertain if Tomcat is started with the -security option \n                         Default Value: By default the -security option is not utilized.  References: 1. http://tomcat.apache.org/tomcat-5.5-doc/security-manager-howto.html"
  impact 1.0
  describe bash("cat /etc/tomcat6/tomcat6.conf") do
    its("stdout") { should match(/^SECURITY_MANAGER\s*=\s*"true"$/) }
  end
end

control "ensure-web-content-directory-is-on-a-separate-partition-from-the-tomcat-system-files" do
  title "Ensure Web content directory is on a separate partition from the Tomcat system files"
  desc  "Description: Store web content on a separate partition from Tomcat system files.  Rationale: The web document directory is where the files which are severed to the end user reside. In the past, directory traversal exploits have allowed malicious users to play havoc on a web server including executing code, uploading files, and reading sensitive data. Even if you do not have any directory traversal exploits in your server or code at this time, that doesn't mean they won't be introduced in the future. Moving your web document directory onto a different partition will prevent these kinds of attacks from doing more damage to other part of the file system.  Level: 1 Audit: Locate the Tomcat system files and web content directory. Review the system partitions and ensure the system files and web content directory are on separate partitions.  # more /etc/init.d/tomcat* | grep $CATALINA_HOME # more /etc/fstab \n                         Default Value: Not Applicable"
  impact 1.0
end

control "force-ssl-when-accessing-the-manager-application" do
  title "Force SSL when accessing the manager application"
  desc  "Description: Use the transport-guarantee attribute to ensure SSL protection when accessing the manager application.  Rationale: By default when accessing the manager application, login information is sent over the wire in plain text. By using the transport-guarantee attribute within web.xml, SSL is enforced. NOTE: This requires SSL to be configured.  Level: 1 Audit: Ensure $CATALINA_HOME/webapps/manager/WEB-INF/web.xml in Tomcat 6.X and $CATALINA_HOME/server/webapps/manager/WEB-INF/web.xml in Tomcat 5.5 has the <transport-guarantee> attribute set to CONFIDENTIAL.  # grep transport-guarantee \\  $CATALINA_HOME/webapps/manager/WEB-INF/web.xml \n                         Default Value: By default this configuration is not present.  References: 1. http://www.owasp.org/index.php/Securing_tomcat"
  impact 1.0
  describe.one do
    describe file("#{attr_catalinabase}/server/webapps/manager/WEB-INF/web.xml") do
      its("content") { should match(/<transport-guarantee>CONFIDENTIAL<\/transport-guarantee>/) }
    end
    describe file("#{attr_catalinabase}/webapps/manager/WEB-INF/web.xml") do
      its("content") { should match(/<transport-guarantee>CONFIDENTIAL<\/transport-guarantee>/) }
    end
    describe bash("test -e #{attr_catalinabase}/webapps/manager/WEB-INF/web.xml") do
      its("exit_status") { should eq 0 }
    end
    describe bash("test -e #{attr_catalinabase}/server/webapps/manager/WEB-INF/web.xml") do
      its("exit_status") { should eq 0 }
    end
  end
end

control "enable-strict-servlet-compliance" do
  title "Enable strict servlet Compliance"
  desc  "Description: The STRICT_SERVLET_COMPLIANCE influences Tomcat's behavior in several subtle ways. See the References below for the complete list. It is recommended that STRICT_SERVLET_COMPLIANCE be set to true.  Rationale: When STRICT_SERVLET_COMPLIANCE is set to true, Tomcat will always send an HTTP Content-type header when responding to requests. This is significant as the behavior of web browsers is inconsistent in the absence of the Content-type header. Some browsers will attempt to determine the appropriate content-type by sniffing  Level: 1 Audit: Ensure the above parameter is added to the start up script which by default is located at $CATALINA_HOME\\bin\\catalina.sh. \n                         Default Value: By default this configuration parameter is not present.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/config/systemprops.html 2. http://mail-archives.apache.org/mod_mbox/tomcat-dev/200906.mbox/%3C4A315DD0.8070706@apache.org%3E"
  impact 1.0
  describe bash("egrep \"\\-Dorg.apache.catalina.STRICT_SERVLET_COMPLIANCE=true\" #{attr_catalinabase}/bin/catalina.sh") do
    its("exit_status") { should eq 0 }
  end
end

control "turn-off-session-façade-recycling" do
  title "Turn off session façade recycling"
  desc  "Description: The RECYCLE_FACADES can specify if a new façade will be created for each request. If a new façade is not created there is a potential for information leakage from other sessions.  Rationale: When RECYCLE_FACADES is set to true, Tomcat will recycle the session façade between requests. This will allow for information leakage between requests.  Level: 1 Audit: Ensure the above parameter is added to the start up script which by default is located at $CATALINA_HOME\\bin\\catalina.sh. \n                         Default Value: By default recycling of facades is set to false.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/config/systemprops.html 2. http://www.jeremythomerson.com/blog/2008/11/apachecon-securing-apache-tomcat-for-your-environment/"
  impact 1.0
  describe bash("egrep \"\\-Dorg.apache.catalina.connector.RECYCLE_FACADES=false\" #{attr_catalinabase}/bin/catalina.sh") do
    its("exit_status") { should eq 0 }
  end
end

control "do-not-allow-symbolic-linking" do
  title "Do not allow symbolic linking"
  desc  "Description: Symbolic links allows one application to include the libraries from another. This allows for re-use of code but also allows for potential security issues when applications include libraries from other applications they should not have access to. \n                         Rationale: Allowing symbolic links opens up all Tomcat versions prior to 6.0.18 to directory traversal vulnerability. Also there is a potential that an application could link to another application it should not be linking too. On case-insensitive operating systems there is also the threat of source code disclosure.  Level: 1 Audit: Ensure all context.xml have the allowLinking attribute set to false or allowLinking does not exist.  # find . -name context.xml | xargs grep \"allowLinking\" \n                         Default Value: By default allowLinking has a value of false.  Reference: 1. http://eu.apachecon.com/presentation/materials/78/2009-03-26-SecuringApacheTomcat.pdf 2. http://tomcat.apache.org/tomcat-6.0-doc/config/context.html"
  impact 1.0
  describe bash("find #{attr_catalinabase} -name context.xml | xargs grep \"allowLinking\"") do
    its("stdout") { should_not match(/allowLinking\s*=\s*"true"/) }
  end
end

control "do-not-run-applications-as-privileged" do
  title "Do not run applications as privileged"
  desc  "Description: Setting the privileged attribute for an application changes the class loader to the Server class loader instead of the Shared class loader. \n                         Rationale: Running an application in privileged mode allows an application to load the manager libraries.  Level: 1 Audit: Ensure all context.xml have the privileged attribute set to false or privileged does not exist.  # find . -name context.xml | xargs grep \"privileged\" \n                         Default Value: By default privileged has a value of false.  Reference: 1. http://eu.apachecon.com/presentation/materials/78/2009-03-26-SecuringApacheTomcat.pdf 2. http://tomcat.apache.org/tomcat-6.0-doc/config/context.html"
  impact 1.0
  describe bash("find #{attr_catalinabase} -name context.xml | xargs grep \"privileged\"") do
    its("stdout") { should_not match(/privileged\s*=\s*"true"/) }
  end
end

control "do-not-allow-cross-context-requests" do
  title "Do not allow cross context requests"
  desc  "Description: Setting crossContext to true allows for an application to call ServletConext.getContext to return a dispatcher for another application. \n                         Rationale: Allowing crossContext creates the possibility for a malicious application to make requests to a restricted application.  Level: 1 Audit: Ensure all context.xml have the crossContext attribute set to false or crossContext does not exist.  # find . -name context.xml | xargs grep \"crossContext\" \n                         Default Value: By default crossContext has a value of false.  Reference: 1. http://eu.apachecon.com/presentation/materials/78/2009-03-26-SecuringApacheTomcat.pdf 2. http://tomcat.apache.org/tomcat-6.0-doc/config/context.html"
  impact 1.0
  describe bash("find #{attr_catalinabase} -name context.xml | xargs grep \"crossContext\"") do
    its("stdout") { should_not match(/crossContext\s*=\s*"true"/) }
  end
end
