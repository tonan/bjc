attr_catalinabase = attribute('catalina.base',{
  title: '$CATALINA_BASE',
  default: '/usr/share/tomcat6',
})

attr_catalinahome = attribute('catalina.home',{
  title: '$CATALINA_HOME',
  default: '/usr/share/tomcat6',
})

attr_tomcatfileuser = attribute('tomcat.fileuser',{
  title: 'Tomcat file resource owner user ID',
  default: 'tomcat',
})

attr_tomcatfilegroup = attribute('tomcat.filegroup',{
  title: 'Tomcat file resource group ID ',
  default: 'tomcat',
})

control "do-not-install-tomcat-on-a-multi-use-system" do
  title "Do not install Tomcat on a multi-use system"
  desc  "Description: Servers often expose a variety of services or daemons. It is recommended that the number of services and daemons executing on the Tomcat server be limited to those necessary.  Rationale: Maintaining a server for a single purpose increases the security of your application and system. The more services which are exposed to an attacker, the more potential vectors an attacker has to exploit the system. Tomcat services should function as application servers only and should not be mixed with other functions.  Level: 2 Audit: Leverage the package or services manager for your OS to uninstall or disable unneeded services. On Redhat systems, the following will produce the current service/daemon list:  chkconfig --list \n                         Default Value: NA"
  impact 0.0
end

control "remove-extraneous-files-and-directories" do
  title "Remove extraneous files and directories"
  desc  "Description: The installation may provide example applications, documentation, and other directories which may not serve a production use.  Rationale: Removing sample resources is a defense in depth measure that reduces potential exposures introduced by these resources.  Level: 2 Audit: Perform the following to determine the existence of extraneous resources: 1. List all files extraneous files. The following should yield no output: $ ls -l $CATALINA_HOME/webapps/js-examples \\  $CATALINA_HOME/webapps/servlet-example \\  $CATALINA_HOME/webapps/webdav \\  $CATALINA_HOME/webapps/tomcat-docs \\  $CATALINA_HOME/webapps/balancer \\  $CATALINA_HOME/webapps/ROOT/admin \\  $CATALINA_HOME/webapps/examples  \\  $CATALINA_HOME/server/webapps/manager \\  $CATALINA_HOME/conf/Catalina/localhost/host-manager.xml \\  $CATALINA_HOME/conf/Catalina/localhost/manager.xml \n                         Default Value: Depending on your install method, default extraneous resources will vary."
  impact 1.0
  describe bash("test -e #{attr_catalinabase}/webapps/js-examples") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/servlet-example") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/webdav") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/tomcat-docs") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/balancer") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/ROOT/admin") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/examples") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/server/webapps/manager") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/conf/Catalina/localhost/host-manager.xml") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/conf/Catalina/localhost/manager.xml") do
    its("exit_status") { should eq 0 }
  end
end

control "alter-the-advertised-serverinfo-string" do
  title "Alter the Advertised server.info String"
  desc  "Description: The server.info attribute contains the name of the application service. This value is presented to Tomcat clients when clients connect to the tomcat server.  Rationale: Altering the server.info attribute may make it harder for attackers to determine which vulnerabilities affect the server platform.  Level: 2 Audit: Perform the following to determine if the server.info value has been changed:  1. Extract the ServerInfo.properties file and examine the server.info attribute.  For Tomcat 5.5 $ cd $CATALINA_HOME/server/lib  For Tomcat 6.X $ cd $CATALINA_HOME/lib $ jar xf catalina.jar org/apache/catalina/util/ServerInfo.properties $ grep server.info org/apache/catalina/util/ServerInfo.properties  Default Value: The default value for the server.info attribute is Apache Tomcat/<MajorVer>.<MinorVer>. For example, Apache Tomcat/5.5.  References: 1. http://www.owasp.org/index.php/Securing_tomcat"
  impact 0.0
end

control "alter-the-advertised-servernumber-string" do
  title "Alter the Advertised server.number String"
  desc  "Description: The server.number attribute represents the specific version of Tomcat that is executing. This value is presented to Tomcat clients when connect.  Rationale: Advertising a valid server version may provide attackers with information useful for locating vulnerabilities that affect the server platform. Altering the server version string may make it harder for attackers to determine which vulnerabilities affect the server platform.  Level: 2 Audit: Perform the following to determine if the server.number value has been changed:  1. Extract the ServerInfo.properties file and examine the server.number attribute. For Tomcat 5.5 $ cd $CATALINA_HOME/server/lib For Tomcat 6.X $ cd $CATALINA_HOME/lib $ jar xf catalina.jar org/apache/catalina/util/ServerInfo.properties $ grep server.number org/apache/catalina/util/ServerInfo.properties  Default Value: The default value for the server.number attribute is a four part version number, such as 5.5.20.0.  References: 1. http://techgurulive.com/2009/05/27/how-to-hide-tomcat-version/"
  impact 0.0
end

control "alter-the-advertised-serverbuilt-date" do
  title "Alter the Advertised server.built Date"
  desc  "Description: The server.built date represents the date which Tomcat was compiled and packaged. This value is presented to Tomcat clients when clients connect to the server.  Rationale: Altering the server.built string may make it harder for attackers to fingerprint which vulnerabilities affect the server platform.  Level: 2 Audit: Perform the following to determine if the server.built value has been changed:  1. Extract the ServerInfo.properties file and examine the server.built attribute.  For Tomcat 5.5 $ cd $CATALINA_HOME/server/lib  For Tomcat 6.X $ cd $CATALINA_HOME/lib $ jar xf catalina.jar org/apache/catalina/util/ServerInfo.properties $ grep server.built org/apache/catalina/util/ServerInfo.properties  Default Value: The default value for the server.built attribute is build date and time. For example, Jul 8 2008 11:40:35."
  impact 0.0
end

control "disable-x-powered-by-http-header-and-rename-the-server-value-for-all-connectors" do
  title "Disable X-Powered-By HTTP Header and Rename the Server Value for all Connectors"
  desc  "Description: The xpoweredBy setting determines if Apache Tomcat will advertise its presence via the X-Powered-By HTTP header. It is recommended that this value be set to false. The server attribute overrides the default value that is sent down in the HTTP header further masking Apache Tomcat.  Rationale: Preventing Tomcat from advertising its presence in this manner may make it harder for attackers to determine which vulnerabilities affect the server platform.  Level: 2 Audit: Perform the following to determine if the server platform, as advertised in the HTTP Server header, has been changed:  1. Locate all Connector elements in $CATALINA_HOME/conf/server.xml. 2. Ensure each Connector has a server attribute and that the server attribute does not reflect Apache Tomcat. Also, make sure that the xpoweredBy attribute is NOT set to true. \n                         Default Value: Tomcat does not advertise the X-Powered-By HTTP header by default. Tomcat will only advertise in this manner if the xpoweredBy attribute is present and set to true.  References: 1. http://tomcat.apache.org/tomcat-5.5-doc/config/http.html"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should_not match(/xpoweredBy\s*=\s*"true"/) }
  end
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/server\s*=\s*"[^"]+"/) }
  end
end

control "disable-the-shutdown-port" do
  title "Disable the Shutdown port"
  desc  "Description: Tomcat listens on TCP port 8005 to accept shutdown requests. By connecting to this port and sending the SHUTDOWN command, all applications within Tomcat are halted. The shutdown port is not exposed to the network as it is bound to the loopback interface. If this functionality is not used, it is recommended that the Shutdown port be disabled.  Rationale: Disabling the Shutdown port will eliminate the risk of malicious local entities using the shutdown command to disable the Tomcat server.  Level: 2 Audit: Perform the following to determine if the shutdown port has been disabled:  1. Ensure the port attribute in $CATALINA_HOME/conf/server.xml is set to -1. $ cd $CATALINA_HOME/conf/ $ grep '<Server[[:space:]]\\+[^>]*port[[:space:]]*=[[:space:]]*\"-1\"' server.xml \n                         Default Value: The shutdown port is enabled on TCP port 8005, bound to the loopback address.  References: 1. http://tomcat.apache.org/tomcat-5.5-doc/config/server.html"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/<Server\s+[^>]*port\s*=\s*"-1"/) }
  end
end

control "use-secure-realms" do
  title "Use secure Realms"
  desc  "Description: A realm is a database of usernames and passwords used to identify valid users of web applications. Review the Realms configuration to ensure Tomcat is configured to use JDBCRealm, DataSourceRealm, JNDIRealm, or JAASRealm. Specifically, Tomcat should not utilize MemoryRealm. \n                         Rationale: According to the Tomcat documentation, MemoryRealm is not designed for production usage and could result in reduced availability.  Level: 2 Audit: Perform the following to ensure the MemoryRealm is not in use:  # grep \"Realm className\" $CATALINA_HOME/conf/server.xml | grep MemoryRealm  The above command should not emit any output.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/realm-howto.html"
  impact 1.0
  describe bash("cat #{attr_catalinabase}/conf/server.xml") do
    its("stdout") { should_not match(/Realm className.*MemoryRealm/) }
  end
end

control "use-lockout-realms" do
  title "Use LockOut Realms"
  desc  "Description: A LockOut realm wraps around standard realms adding the ability to lock a user out after multiple failed logins. \n                         Rationale: Locking out a user after multiple failed logins slows down attackers from brute forcing logins.  Level: 2 Audit: Perform the following to check to see if a LockOut realm is being used:  # grep \"LockOutRealm\" $CATALINA_HOME/conf/server.xml \n                         References: 1. http://eu.apachecon.com/presentation/materials/78/2009-03-26-SecuringApacheTomcat.pdf 2. http://tomcat.apache.org/tomcat-6.0-doc/config/realm.html"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/.*LockOutRealm.*/) }
  end
end

control "setup-client-cert-authentication" do
  title "Setup Client-cert Authentication"
  desc  "Description: Client-cert authentication requires that each client connecting to the server has a certificate used to authenticate. This is generally regarded as strong authentication than a password as it requires the client to have the cert and not just know a password.  Rationale: Certificate based authentication is more secure than password based authentication.  Level: 2 Audit: Review the Connector configuration in server.xml and ensure the clientAuth parameter is set to true. \n                         Default Value: Not configured  References: 1. http://wiki.apache.org/tomcat/SSLWithFORMFallback 2. http://tomcat.apache.org/tomcat-5.5-doc/ssl-howto.html"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/clientAuth\s*=\s*"true"/) }
  end
end

control "application-specific-logging" do
  title "Application specific logging"
  desc  "Description: By default, java.util.logging does not provide the capabilities to configure per-web application settings, only per VM.  In order to overcome this limitation Tomcat implements JULI as a wrapper for java.util.logging. JULI provides additional configuration functionality so you can set each web application with different logging specifications.  Rationale: Establishing per application logging profiles will help ensure that each application's logging verbosity is set to an appropriate level in order to provide appropriate information when needed for security review.  Level: 2 Audit: Ensure a logging.properties file is locate at $CATALINA_BASE\\<app_name>\\WEB-INF\\classes. \n                         Default Value: By default, per application logging is not configured."
  impact 1.0
  describe bash("find -L #{attr_catalinabase} -name classes | xargs -I{} test -e {}/logging.properties || echo \"fail\"") do
    its("stdout") { should_not match(/^fail$/) }
  end
end

control "ensure-classname-is-set-correctly-in-contextxml" do
  title "Ensure className is set correctly in context.xml"
  desc  "Description: Ensure the className attribute is set to FastCommonAccessLogValve. The className attribute determines the access log valve to be used for logging.  Rationale: Some log valves are not suited for production and should be used. Apache recommends org.apache.catalina.valves.FastCommonAccessLogValve  Level: 2 Audit: Execute the following to ensure className is set properly:  # grep org.apache.catalina.valves.FastCommonAccessLogValve context.xml \n                         Default Value: Does not exist by default."
  impact 1.0
  describe bash("find -L #{attr_catalinabase} -name context.xml | xargs grep org.apache.catalina.valves.FastCommonAccessLogValve || echo \"fail\"") do
    its("stdout") { should_not match(/^fail$/) }
  end
end

control "configure-log-file-size-limit" do
  title "Configure log file size limit"
  desc  "Description: By default, the logging.properties file will have no defined limit for the log file size. This is a potential denial of service attack as it would be possible to fill a drive or partition containing the log files.  Rationale: Establishing a maximum log size that is smaller than the partition size will help mitigate the risk of an attacker maliciously exhausting disk space.  Level: 2 Audit: Validate the max file limit is not greater than the size of the partition where the log files are stored. \n                         Default Value: No limit by default."
  impact 1.0
  describe bash("find -L #{attr_catalinabase} -name logging.properties | xargs grep ^java.util.logging.FileHandler.limit || echo \"fail\"") do
    its("stdout") { should_not match(/^fail$/) }
  end
end

control "disabling-auto-deployment-of-applications" do
  title "Disabling auto deployment of applications"
  desc  "Description: Tomcat allows auto deployment of applications while Tomcat is running. It is recommended that this capability be disabled.  Rationale: This could allow malicious or untested applications to be deployed and should be disabled.  Level: 2 Audit: Perform the following to ensure autoDeploy is set to false.  # grep \"autoDeploy\" $CATALINA_HOME/conf/server.xml \n                         Default Value: autoDeploy is set to true  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/deployer-howto.html#Deployment%20on%20Tomcat%20startup"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/autoDeploy\s*=\s*"false"/) }
  end
end

control "disable-deploy-on-startup-of-applications" do
  title "Disable deploy on startup of applications"
  desc  "Description: Tomcat allows auto deployment of applications. It is recommended that this capability be disabled.  Rationale: This could allow malicious or untested applications to be deployed and should be disabled.  Level: 2 Audit: Perform the following to ensure deployOnStartup is set to false.  # grep \"deployOnStartup\" $CATALINA_HOME/conf/server.xml \n                         Default Value: deployOnStartup is set to true  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/deployer-howto.html#Deployment%20on%20Tomcat%20startup"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/server.xml") do
    its("content") { should match(/deployOnStartup\s*=\s*"false"/) }
  end
end

control "restrict-access-to-the-web-administration" do
  title "Restrict access to the web administration"
  desc  "Description: Limit access to the web administration application to only those with a required needed.  Rationale: Limiting access to the least privilege required will ensure only those people with required need have access to a resource. The web administration application should be limited to only administrators.  Level: 2 Audit: Review $CATALINA_HOME/conf/server.xml to ascertain that the RemoteAddrValve option is uncommented and configured to only allow access to systems required to connect. \n                         Default Value: By default, this configuration is not present.  References: 1. http://www.unidata.ucar.edu/Projects/THREDDS/tech/reference/TomcatSecurity.html"
  impact 0.0
end

control "restrict-manager-application" do
  title "Restrict manager application"
  desc  "Description: Limit access to the manager application to only those with a required needed.  Rationale: Limiting access to the least privilege required will ensure only those people with required need have access to a resource. The manager application should be limited to only administrators.  Level: 2 Audit: Review $CATALINA_HOME/conf/Catalina/localhost/webapps/manager.xml on Tomcat 5.5 and $CATALINA_HOME/webapps/host-manager/manager.xml on Tomcat 6.X to ascertain that the RemoteAddrValve option is uncommented and configured to only allow access to systems required to connect. \n                         Default Value: By default this setting is not present.  References: 1. http://www.unidata.ucar.edu/Projects/THREDDS/tech/reference/TomcatSecurity.html"
  impact 0.0
end

control "rename-the-manager-application" do
  title "Rename the manager application"
  desc  "Description: The manager application allows administrators to manage Tomcat remotely via a web interface. The manager application should be renamed to make it harder for attackers or automated scripts to locate. \n                         Rationale: Obscurity can be helpful when used with other security measures. By relocating the manager applications, an attacker will need to guess its location rather than simply navigate to the standard location in order to carry out an attack.  Level: 2 Audit: Ensure $CATALINA_HOME/conf/Catalina/localhost/manager.xml, $CATALINA_HOME/webapps/host-manager/manager.xml, $CATALINA_HOME/server/webapps/manager and $CATALINA_HOME/webapps/manager do not exsist. \n                         Default Value: The default name of the manager application is \"manager\" and is located at:  For Tomcat 5.5: $CATALINA_HOME/server/webapps/manager  For Tomcat 6.X: $CATALINA_HOME/webapps/manager  References: 1. http://www.owasp.org/index.php/Securing_tomcat"
  impact 1.0
  describe bash("test -e #{attr_catalinabase}/conf/Catalina/localhost/manager.xml") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/host-manager/manager.xml") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/server/webapps/manager") do
    its("exit_status") { should eq 0 }
  end
  describe bash("test -e #{attr_catalinabase}/webapps/manager") do
    its("exit_status") { should eq 0 }
  end
end

control "do-not-allow-additional-path-delimiters" do
  title "Do not allow additional path delimiters"
  desc  "Description: Being able to specify different path-delimiters on Tomcat creates the possibility that an attacker can access applications that were previously blocked a proxy like mod_proxy. \n                         Rationale: Allowing additional path-delimiters allows for an attacker to get an application or area that was not previously visible.  Level: 2 Audit: Ensure the above parameters are added to the start up script which by default is located at $CATALINA_HOME\\bin\\catalina.sh. \n                         Default Value: By default allowing additional parameters is set to false.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/config/systemprops.html 2. http://www.jeremythomerson.com/blog/2008/11/apachecon-securing-apache-tomcat-for-your-environment/ 3. https://www.covalent.net/download/patch2.0/README-ers-3.1.0-patch-tomcat-20070315.txt"
  impact 1.0
  describe bash("egrep \"\\-Dorg.apache.catalina.connector.CoyoteAdapter.ALLOW_BACKSLASH=false\" #{attr_catalinabase}/bin/catalina.sh ") do
    its("exit_status") { should eq 0 }
  end
  describe bash("egrep \"\\-Dorg.apache.tomcat.util.buf.UDecoder.ALLOW_ENCODED_SLASH=false\" #{attr_catalinabase}/bin/catalina.sh") do
    its("exit_status") { should eq 0 }
  end
end

control "do-not-allow-custom-header-status-messages" do
  title "Do not allow custom header status messages"
  desc  "Description: Being able to specify custom status messages opens up the possibility for additional headers to be injected. If custom header status messages are required make sure it is only in US-ASCII and does not include any user-supplied data. \n                         Rationale: Allowing user-supplied data into a header allows the possibility of XSS.  Level: 2 Audit: Ensure the above parameter is added to the start up script which by default is located at $CATALINA_HOME\\bin\\catalina.sh. \n                         Default Value: By default allowing custom header status messages is set to false.  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/config/systemprops.html http://www.jeremythomerson.com/blog/2008/11/apachecon-securing-apache-tomcat-for-your-environment/2."
  impact 1.0
  describe bash("egrep \"\\-Dorg.apache.coyote.USE_CUSTOM_STATUS_MSG_IN_HEADER=false\" #{attr_catalinabase}/bin/catalina.sh") do
    its("exit_status") { should eq 0 }
  end
end

control "configure-connectiontimeout" do
  title "Configure connectionTimeout"
  desc  "Description: The connectionTimeout setting allows Tomcat to close idle sockets after a specific amount of time to save system resources.  Rationale: Closing idle sockets reduces system resource usage thus can provide better performance and help protect against Denial of Service attacks.  Level: 2 Audit: Locate each connectionTimeout setting in $CATALINA_HOME/conf/server.xml and verify the setting is correct.  # grep connectionTimeout $CATALINA_HOME/conf/server.xml \n                         Default Value: connectionTimeout is set to 60000  References: 1. http://tomcat.apache.org/connectors-doc/generic_howto/timeouts.html"
  impact 0.0
end

control "configure-maxhttpheadersize" do
  title "Configure maxHttpHeaderSize"
  desc  "Description: The maxHttpHeaderSize limits the size of the request and response headers defined in bytes. If not specified, the default is 8192 bytes.  Rationale: Limiting the size of the header request can help protect against Denial of Service requests.  Level: 2 Audit: Locate each maxHttpHeaderSize setting in $CATALINA_HOME/conf/server.xml and verify that they are set to 8192.  # grep maxHttpHeaderSize $CATALINA_HOME/conf/server.xml \n                         Default Value: maxHttpHeaderSize is set to 8192  References: 1. http://tomcat.apache.org/tomcat-6.0-doc/config/http.html"
  impact 1.0
  describe bash("egrep -i \"maxHttpHeaderSize\" #{attr_catalinabase}/conf/server.xml").stdout.to_s.[](/maxHttpHeaderSize\s*=\s*"(\d+)"/, 1) do
    it { should cmp <= 8192 }
  end
end

control "force-ssl-for-all-applications" do
  title "Force SSL for all applications"
  desc  "Description: Use the transport-guarantee attribute to ensure SSL protection when accessing all applications. This can be overridden to be disabled on a per application basis in the application configuration.  Rationale: By default when accessing applications SSL will be enforced to protect information sent over the network. By using the transport-guarantee attribute within web.xml, SSL is enforced. NOTE: This requires SSL to be configured.  Level: 2 Audit: Ensure $CATALINA_HOME/conf/web.xml has the <transport-guarantee> attribute set to CONFIDENTIAL.  # grep transport-guarantee $CATALINA_HOME/conf/web.xml \n                         Default Value: By default this configuration is not present.  References: http://www.owasp.org/index.php/Securing_tomcat1."
  impact 1.0
  describe file("#{attr_catalinabase}/conf/web.xml") do
    its("content") { should match(/<transport-guarantee>CONFIDENTIAL<\/transport-guarantee>/) }
  end
end

control "increase-the-entropy-in-session-identifiers" do
  title "Increase the entropy in session identifiers"
  desc  "Description: Having a server that has deterministic session identifiers can lead to session hi-jacking. Specifying a randomClass attribute allows for truly random session identifiers. \n                         Rationale: By default the entropy attribute on session managers uses the string representation of the Manager class name. Leading to a deterministic session identifier.  Level: 2 Audit: Ensure $CATALINA_HOME/conf/context.xml has the randomClass attribute set to java.security.SecureRandom.  # grep randomClass $CATALINA_HOME/conf/context.xml \n                         Default Value: By default the string representation of the Manager class is used for entropy.  Reference: 1. http://www.jeremythomerson.com/blog/2008/11/apachecon-securing-apache-tomcat-for-your-environment/"
  impact 1.0
  describe file("#{attr_catalinabase}/conf/context.xml") do
    its("content") { should match(/randomClass\s*=\s*"java.security.SecureRandom"/) }
  end
end

control "do-not-resolve-hosts-on-logging-valves" do
  title "Do not resolve hosts on logging valves"
  desc  "Description: Setting resolveHosts to true on logging valves requires a DNS look-up before logging the information. This adds additional resources when logging. \n                         Rationale: Allowing resolveHosts adds additional overhead that is rarely needed.  Level: 2 Audit: Ensure all Valve nodes have the resolveHosts attribute set to false or resolveHosts does not exist.  # find . -name *.xml | xargs grep \"resolveHosts\" \n                         Default Value: By default resolveHosts has a value of false.  Reference: 1. http://eu.apachecon.com/presentation/materials/78/2009-03-26-SecuringApacheTomcat.pdf 2. http://tomcat.apache.org/tomcat-6.0-doc/config/valve.html  Appendix A: Change History Date Version Changes for this version December 12th , 2009"
  impact 1.0
  describe bash("find #{attr_catalinabase} -name context.xml | xargs grep \"resolveHosts\"") do
    its("stdout") { should_not match(/resolveHosts\s*=\s*"true"/) }
  end
end
